<?php
require("../global/conexion.php");
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<title>Empresa -  G&R GLOBAL ELECTRIC SOLUCION INDUSTRIAL</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="https://i.postimg.cc/sxFD4KB8/d60966d3-54d3-444a-b720-110e5a33024c-auto-x2-removebg-preview-removebg-preview-1.png"/><!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../fonts/linearicons-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="../vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendor/perfect-scrollbar/perfect-scrollbar.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../icons.css">

	<link rel="stylesheet" type="text/css" href="../css/util.css">
	<link rel="stylesheet" type="text/css" href="../css/styles.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
	<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
<!--===============================================================================================-->
</head>
<body class="animsition">
    <div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/es_LA/sdk.js#xfbml=1&version=v14.0"></script>
	
	<!-- Header -->
	<?php
	include '../templates/header-v2.php'
	?>

	<!-- Cart -->



	<!-- Title page -->
	<section class="bg-img1 txt-center p-lr-15 p-tb-92" style="background-image: url('https://img.freepik.com/foto-gratis/portatil-digital-que-trabaja-concepto-negocio-global_53876-23307.jpg?w=826&t=st=1661571696~exp=1661572296~hmac=b276e6b444b44b5d30d156a84ab09000e133225eb0e86754fb88928e9a6e2464');">
		<h2 class="ltext-105 cl11 txt-center">
			Empresa
		</h2>
	</section>	


	<!-- Content page -->
	<section class="bg0 p-t-75">
		<div class="container">
			<div class="row">
				<div class="col-md-7 col-lg-8">
				    <?php
								$consulta = $conn->query("SELECT * FROM `Nosotros` where id='1'");
								while ($fila = $consulta->fetch_array()) {
				?>
					<div class="p-t-7 p-r-85 p-r-15-lg p-r-0-md">
					    
						<h2 class="mtext-111 cl11 p-b-16">
							<?php echo $fila['Titulo']; ?>
						</h2>

				
					
						<p class="stext-113 cl6 p-b-26" style="font-size: 20px;">
							<?php echo nl2br($fila['texto']); ?>
						</p>

						
					</div>
				</div>

				<div class="col-11 col-md-5 col-lg-4 m-lr-auto">
					<div class="how-bor1 ">
						<div class="hov-img0">
							<img src="<?php echo $fila['imagen']; ?>" alt="IMG">
						</div>
					</div>
				</div>
				<?php } ?>
			</div>
			
			<div class="row">
				<div class="order-md-2 col-md-7 col-lg-8 p-b-30">
				    
					<div class="p-t-7 p-l-85 p-l-15-lg p-l-0-md">
					    
					    <?php
								$consulta = $conn->query("SELECT * FROM `Nosotros` where id='2'");
								while ($fila = $consulta->fetch_array()) {
				?>
						<h3 class="mtext-111 cl11 p-b-16">
								<?php echo $fila['Titulo']; ?>
						</h3>

						<p class="stext-113 cl6 p-b-26">
							<?php echo nl2br($fila['texto']); ?>
						</p>
						<?php } ?>
                        <?php
								$consulta = $conn->query("SELECT * FROM `Nosotros` where id='3'");
								while ($fila = $consulta->fetch_array()) {
				?>
						<h3 class="mtext-111 cl11 p-b-16">
								<?php echo $fila['Titulo']; ?>
						</h3>

						<p class="stext-113 cl6 p-b-26">
							<?php echo nl2br($fila['texto']); ?>
						</p>
						<?php } ?>
						
					</div>
						

						

					
				</div>

				<div class="order-md-1 col-11 col-md-5 col-lg-4 m-lr-auto p-b-30">
					<div class="how-bor2">
						<div class="hov-img0">
						    <?php
								$consulta = $conn->query("SELECT * FROM `Nosotros` where id='2'");
								while ($fila = $consulta->fetch_array()) {
				?>
							<img src="<?php echo $fila['imagen']; ?>" alt="IMG">
							<?php } ?>
						</div>
					</div>
				</div>
				
			</div>
		
<div class="row">
				<div class="col-md-7 col-lg-8">
				    <?php
								$consulta = $conn->query("SELECT * FROM `Nosotros` where id='4'");
								while ($fila = $consulta->fetch_array()) {
				?>
					<div class="p-t-7 p-r-85 p-r-15-lg p-r-0-md">
					    
						<h3 class="mtext-111 cl11 p-b-16">
							<?php echo $fila['Titulo']; ?>
						</h3>

				
					
						<p class="stext-113 cl6 p-b-26">
							<?php echo nl2br($fila['texto']); ?>
						</p>

						
					</div>
				</div>

				<div class="col-11 col-md-5 col-lg-4 m-lr-auto">
					<div class="how-bor1 ">
						<div class="hov-img0">
							<img src="<?php echo $fila['imagen']; ?>" alt="IMG">
						</div>
					</div>
				</div>
				<?php } ?>
			</div>
		</div>
		<style>
	.how-bor2::before, .how-bor1::before {
    content: "";
    display: block;
    position: absolute;
    z-index: -1;
    width: 100%;
    height: 100%;
    border: 3px solid #ccc0;
    
}
.block2-btn{

    

}
</style>
	</section>
	<section class="sec-blog bg0 p-t-60 p-b-90">
		<div class="container">
			<div class="p-b-66">
				<h3 class="ltext-105 cl11 txt-center respon1">
					Nuestras Publicaciones
				</h3>
			</div>

			<div class="row">
			<?php
								$consulta = $conn->query("SELECT * FROM `Publicacion_referencial_facebock`");
								while ($fila = $consulta->fetch_array()) {
				?>
				<div class="col-sm-6 col-md-4 p-b-40">
					<div class="blog-item">
						<div class="fb-post" data-href="<?php echo$fila['link_de_publicidad']; ?>" data-width="300" data-show-text="true"></div>
					</div>
				</div>
				<?php } ?>
			</div>
		</div>
	</section>
		

	<!-- Footer -->
	<?php
	include '../templates/footer.php'
	?>


	<!-- Back to top -->
	<div class="btn-back-to-top" id="myBtn">
		<span class="symbol-btn-back-to-top">
			<i class="zmdi zmdi-chevron-up"></i>
		</span>
	</div>

<!--===============================================================================================-->	
	<script src="../vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="../vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="../vendor/bootstrap/js/popper.js"></script>
	<script src="../vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="../vendor/select2/select2.min.js"></script>
	<script>
		$(".js-select2").each(function(){
			$(this).select2({
				minimumResultsForSearch: 20,
				dropdownParent: $(this).next('.dropDownSelect2')
			});
		})
	</script>
<!--===============================================================================================-->
	<script src="../vendor/MagnificPopup/jquery.magnific-popup.min.js"></script>
<!--===============================================================================================-->
	<script src="../vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
	<script>
		$('.js-pscroll').each(function(){
			$(this).css('position','relative');
			$(this).css('overflow','hidden');
			var ps = new PerfectScrollbar(this, {
				wheelSpeed: 1,
				scrollingThreshold: 1000,
				wheelPropagation: false,
			});

			$(window).on('resize', function(){
				ps.update();
			})
		});
	</script>
<!--===============================================================================================-->
	<script src="../js/main.js"></script>
	
</body>
</html>