<header class="header-v2">
		<style>
            .main-menu-m {
    padding-top: 10px;
    padding-bottom: 10px;
    background-color: #eea206;
    

}
			
			.header-v3 .fix-menu-desktop .wrap-menu-desktop {
				background-color: #002133;
				border-color: #002133;
			}

			.block1-txt:hover {
				background-color: rgb(238 163 6 / 46%);
			}

			.header-v2 .wrap-menu-desktop {
				background-color: #002133;
				border-color: #002133;
				top: 0;
			}

			.main-menu>li>a {
				font-family: Poppins-Medium;
				font-size: 14px;
				color: #fff;
				padding: 5px 0px;
				transition: all 0.4s;
				-webkit-transition: all 0.4s;
				-o-transition: all 0.4s;
				-moz-transition: all 0.4s;
			}
		</style>
		<!-- Header desktop -->
		<div class="container-menu-desktop">
			<!-- Topbar -->

			<div class="wrap-menu-desktop">
				<nav class="limiter-menu-desktop container">

					<!-- Logo desktop -->
					<a href="https://www.gyrglobalelectric.com/" class="logo">
					    
<?php
								$consulta = $conn->query("SELECT * FROM `logo` where id='2'");
								while ($fila = $consulta->fetch_array()) {
				                ?>  
						<img src="<?php echo $fila['logo']; ?>" alt="Global Electric solución industrial">
					<?php } ?>					
					</a>
					

					<!-- Menu desktop -->
					<div class="menu-desktop">
						<ul class="main-menu">
						    <li>
								<a href="../EMPRESA/">G&R GLOBAL ELECTRIC</a>
							</li>
							<li>
								<a href="https://www.gyrglobalelectric.com/">Inicio</a>

							</li>

							<li>
								<a href="../PRODUCTOS/">Productos</a>
							</li>

							

							<li>
								<a href="../MARCAS/">Marcas</a>
							</li>

							<li>
								<a href="../CONTACTOS/">Contactenos</a>
							</li>


						</ul>
					</div>

					<!-- Icon header -->

				</nav>
			</div>
		</div>
		<style>
			.wrap-header-mobile {
				height: 150px;
			}

			.hamburger-inner,
			.hamburger-inner:after,
			.hamburger-inner:before {
				background-color: #fff;
			}
		</style>
		<!-- Header Mobile -->
		<div class="wrap-header-mobile">
			<div class="limiter-menu-desktop container" style="padding-right: 0px;
   		 padding-left: 0px;">


				<div class="logo-mobile">
					<a href="https://www.gyrglobalelectric.com/">
					    <?php
								$consulta = $conn->query("SELECT * FROM `logo` where id='2'");
								while ($fila = $consulta->fetch_array()) {
				                ?> 
					    <img style="padding-left: 0px;" src="<?php echo $fila['logo']; ?>" alt="IMG-LOGO">
					    <?php } ?>
					    </a>
				</div>

				<div class="wrap-icon-header flex-w flex-r-m h-full m-r-15">
					<div class="flex-c-m h-full p-r-5">
						<div class="icon-header-item cl2 hov-cl1 trans-04 p-lr-11">
                            <a href="tel:+51981202785">
                                <i class="fa fa-mobile" style="box-sizing: border-box;
					height: 45px;
					width: 45px;
					padding: 5px;
					border: solid 3px #000;
					border-radius: 50%;
					opacity: .7;
					padding-top: 0px;
					padding-right: 10px;
					padding-bottom: 10px;
					padding-left: 11px;
					font-size: 40px;
					color: #000000;"></i></a>
							
						</div>
					</div>
				</div>


				<!-- Button show menu -->
				<div class="btn-show-menu-mobile hamburger hamburger--squeeze">
					<span class="hamburger-box" style="display: block !important;

		left: 3% !important;
		height: 50px;
		width: 50px;
		background-repeat: no-repeat;
		background-position: center;
		margin: 0 auto;
		background-color: #0068a2;">
						<span style="margin-left: 5px;" class="hamburger-inner"></span>
					</span>
				</div>
			</div>
		</div>

		<!-- Menu Mobile -->
		<div class="menu-mobile">


			<ul class="main-menu-m" style="margin-bottom: auto;">
				<li>
					<a href="https://www.gyrglobalelectric.com/">Inicio</a>

				</li>

				<li>
					<a href="../PRODUCTOS/">Productos</a>
				</li>

				<li>
					<a href="../EMPRESA/">G&R GLOBAL ELECTRIC</a>
				</li>

				<li>
					<a href="../MARCAS/">Marcas</a>
				</li>

				<li>
					<a href="../CONTACTOS/">Contactos</a>
				</li>
			</ul>
		</div>

		<!-- Modal Search -->

	</header>