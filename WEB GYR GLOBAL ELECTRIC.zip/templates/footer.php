
<style>
a {
  color: #959595;
  text-decoration: none;
  background-color: transparent;
  -webkit-text-decoration-skip: objects;
}

a:hover {
  color: #eea306;
  text-decoration: underline;
}
.p-b-30 {
    padding-bottom: 6px;
}
.forego{
        background: #00356b;
    border-radius: 20px;
    padding-bottom: 10px;
}
.p-b-10 a {
    color: #dbdbdb!important;
}
.stext-107 {
    color: #dbdbdb!important;
}
.bg35 {background-color: #eea307;}
</style>

<footer class="bg3 p-t-75 p-b-32" style="background-color: #2f2f2f;">
		<div class="container">
			<div class="row">
				<div class="col-sm-6 col-lg-3 p-b-50">
					<h4 class="stext-301 cl0 p-b-30" style="color:#fff">
						Enlaces
					</h4>

					<ul >
						<li class="p-b-10">
							<a href="https://www.gyrglobalelectric.com/">
								Inicio
							</a>
						</li>
                        <li class="p-b-10">
							<a href="https://www.gyrglobalelectric.com/PRODUCTOS/">
								Productos
							</a>
						</li>
                        <li class="p-b-10">
							<a href="https://www.gyrglobalelectric.com/EMPRESA/">
								G&R GLOBAL ELECTRIC
							</a>
						</li>
                        <li class="p-b-10">
							<a href="https://www.gyrglobalelectric.com/MARCAS/">
								Marcas
							</a>
						</li>
						<li class="p-b-10">
							<a href="https://www.gyrglobalelectric.com/CONTACTOS/">
								Contactos
							</a>
						</li>

						
					</ul>
				</div>

				<div class="col-sm-6 col-lg-3 p-b-50">
					<h4 class="stext-301 cl0 p-b-30">
						Categorias
					</h4>

					<ul style="padding-left: 0px;">
			 <?php
								$consulta = $conn->query("SELECT * FROM `tipo-productos`");
								while ($fila = $consulta->fetch_array()) {
				                ?>
				               <li class="p-b-10" style="padding-bottom: 0px;">

							<a style="    font-size: 14px;" href="https://www.gyrglobalelectric.com/PRODUCTOS/">
								<?php echo $fila['nombre']; ?>
							</a>
						</li> 
			    <?php } ?>
						
					</ul>
				</div>

				<div class="col-sm-6 col-lg-3 p-b-50">
					<h4 class="stext-301 cl0 p-b-30">
						SOBRE NOSOTROS
					</h4>

					<p class="stext-107 cl7 size-201" style="color:#959595;font-size: 14px;">
						Global Electric Solución Industrial es una empresa peruana del sector industrial dedicada a la distribución de productos eléctricos como iluminación, electricidad y ferretería con cobertura a nivel nacional .
					</p>


				</div>

				<div class="col-sm-6 col-lg-3 p-b-50">
					<h4 class="stext-301 cl0 p-b-30">
						Contactenos
					</h4>

					<form action="https://formsubmit.co/ventas@gyrglobalelectric.com" method="POST">
						<div class="wrap-input1 w-full p-b-4">
							<div class="contrast-input">
								<input type="text" name="name" class="form-control" placeholder="Nombre" />
							  </div>
							  <div class="contrast-input">
								<input type="email" name="email" class="form-control" placeholder="Email" />
							  </div>
							<div class="focus-input1 trans-04"></div>
						</div>

						<div class="p-t-18">
							<button type="submit" class="flex-c-m stext-101 cl0 size-103 bg35 bor1 hov-btn2 p-lr-15 trans-04">
								Enviar
							</button>
						</div>
					</form>
				</div>
			</div>
<hr style="border-top: 1px solid rgb(255 255 255 / 100%);">
			<div class="p-t-40 forego">
				<div class="flex-c-m flex-w p-b-18">
					<div class="col-sm-6 col-lg-3 p-b-50">
						<h4 class="stext-301 cl0 p-b-30" style="text-align: center;max-width: 100%;">
							Telefonos
						</h4>
	
						<p class="stext-107 cl7 size-201" style="text-align: center;max-width: 100%;">
							+51 981 202 785
						</p>
					</div>
	
					<div class="col-sm-6 col-lg-3 p-b-50">
						<h4 class="stext-301 cl0 p-b-30" style="text-align: center;">
							Direccion
						</h4>
	
						<p class="stext-107 cl7 size-201" style="text-align: center;max-width: 100%;">
							CALLE SANTA FE MZ I LT 6 INMACULADA CONCEPCION - ATE.
						</p>
					</div>
	
					<div class="col-sm-6 col-lg-3 p-b-50">
						<h4 class="stext-301 cl0 p-b-30" style="text-align: center;">
							Correo
						</h4>
	
						<p class="stext-107 cl7 size-201" style="text-align: center;max-width: 100%;">
							ventas@globalelectric.com
						</p>
	
	
					</div>
	
				</div>

				<p class="stext-107 cl6 txt-center">
Copyright &copy;<script>document.write(new Date().getFullYear());</script> | G&R GLOBAL ELECTRIC SOLUCION INDUSTRIAL</a>

				</p>
			</div>
		</div>
	</footer>

    <style>
		.social {
			position: fixed; /* Hacemos que la posición en pantalla sea fija para que siempre se muestre en pantalla*/
			right: 0; /* Establecemos la barra en la izquierda */
			top: 300px; /* Bajamos la barra 200px de arriba a abajo */
			z-index: 2000; /* Utilizamos la propiedad z-index para que no se superponga algún otro elemento como sliders, galerías, etc */
		}
		
			.social ul {
				list-style: none;
			}
		
			.social ul li a {
				display: inline-block;
				color:#fff;
				background: #000;
				padding: 15px 15px;
				text-decoration: none;
				-webkit-transition:all 500ms ease;
				-o-transition:all 500ms ease;
				transition:all 500ms ease; /* Establecemos una transición a todas las propiedades */
			}
		
			.social ul li .icon-facebook {background:#0166e1;} /* Establecemos los colores de cada red social, aprovechando su class */
			.social ul li .icon-twitter {background: #00abf0;}
			.social ul li .icon-instagram {background: radial-gradient(circle at 30% 107%, #fdf497 0%, #fdf497 5%, #fd5949 45%, #d6249f 60%, #285AEB 90%);
		}
			.social ul li .icon-whatsapp {background: #1ad03f;}
			.social ul li .icon-youtube {background: #ae181f;}
		
			.social ul li a:hover {
				background: #000; /* Cambiamos el fondo cuando el usuario pase el mouse */
				padding: 15px 30px; /* Hacemos mas grande el espacio cuando el usuario pase el mouse */
			}
            .btn-back-to-top {
    opacity: 1;
    background-color: #eea307;
  }
            .btn-back-to-top:hover {
    opacity: 1;
    background-color: #eea3075c;
  }
		</style>
	<div class="social">
		<ul>
			<li><a href="https://www.facebook.com/profile.php?id=100085127829983" target="_blank" class="icon-facebook"></a></li>
			<li><a href="https://www.instagram.com/gyr_globalelectric/" target="_blank" class="icon-instagram"></a></li>
			<li><a href="https://api.whatsapp.com/send?phone=51981202785&text=Hola%20G%26R%20GLOBAL%20ELECTRIC%2C%20Me%20gustar%C3%ADa%20contactar%20con%20ustedes%20%3B%20mi%20nombre%20es%3A" target="_blank" class="icon-whatsapp"></a></li>
		</ul>
	</div>
	