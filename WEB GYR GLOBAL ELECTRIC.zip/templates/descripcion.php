<style>

	.imgc{
		max-width: 120%;
    max-height: 100%;
}

</style>
<div class="container">
	<div>

<button type="button" class="how-pos3 hov3 trans-04 js-hide-modal1" data-modal-target="<?php echo $fila['nombre_clave']; ?>" aria-label="Close">
    <img src="https://i.postimg.cc/SK1yZ6Cb/icon-close.png" alt="CLOSE">
</button>


		<div class="row">
			<div class="col-md-6 col-lg-7 p-b-30" style="    
			display: flex;
            justify-content: center;
            align-items: center;">
				<div class="p-l-25 p-r-30 p-lr-0-lg">
					<div>
						<div class="wrap-slick3-dots"></div>
						<div class="wrap-slick3-arrows flex-sb-m flex-w"></div>

						<div class="slick3 gallery-lb">
                            <img style="position: absolute; top: 6px;left: 4px;width: 20%;" src="https://i.postimg.cc/QCP2fWPy/d60966d3-54d3-444a-b720-110e5a33024c-auto-x2-removebg-preview.png" alt="" >
							<img  class="imgc" src="<?php echo $fila['imagen']; ?>" alt="IMG-PRODUCT">



						</div>
					</div>
				</div>
			</div>

			<div class="col-md-6 col-lg-5 p-b-30" >
				<div class="p-r-50 p-t-5 p-lr-0-lg">
					<h4 class="mtext-105 cl2 js-name-detail p-b-14">
						<?php echo $fila['producto']; ?>
					</h4>

				

					<p class="stext-102 cl3 p-t-23">
						Precio incluye I.G.V.
					</p>
					<p class="">
					<b>	Decripción:</b>
					</p>
					<p class="stext-102 cl3">
						<?php echo nl2br($fila['descripción'],false); ?>
					</p>
					<!--  -->


					<!--  -->
					<div class="flex-w flex-m p-l-100 p-t-40 respon7">
					<a href="https://api.whatsapp.com/send?phone=51981202785&text=Hola%20G%26R%20GLOBAL%20ELECTRIC%2C%20Me%20gustar%C3%ADa%20contactar%20con%20ustedes%20y%20comprar%20este%20producto%3A%0A(<?php echo $fila['producto']; ?>).%0AMi%20nombre%20es%3A" type="button" class="btn btn-outline-success"><b>Pidelo por Whatsapp </b>  <i class="fa fa-whatsapp" aria-hidden="true"></i></a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>