<?php
require("../global/conexion.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<title>Productos -  G&R GLOBAL ELECTRIC SOLUCION INDUSTRIAL</title>
	<meta charset="UTF-8">
	<meta name="facebook-domain-verification" content="5kc9dwkxslrcusfyn7nh9upwp32u59" />
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!--===============================================================================================-->
	<?php
								$consulta = $conn->query("SELECT * FROM `logo` where id='1'");
								while ($fila = $consulta->fetch_array()) {
				?>
	<link rel="icon" type="image/png" href="<?php echo $fila['logo']; ?>"/>
	<?php } ?>
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendor/bootstrap/css/bootstrap.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../fonts/iconic/css/material-design-iconic-font.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../fonts/linearicons-v1.0.0/icon-font.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendor/animate/animate.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendor/css-hamburgers/hamburgers.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendor/animsition/css/animsition.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendor/select2/select2.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendor/daterangepicker/daterangepicker.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendor/slick/slick.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendor/MagnificPopup/magnific-popup.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendor/perfect-scrollbar/perfect-scrollbar.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../icons.css">

	<link rel="stylesheet" type="text/css" href="../css/util.css">
	<link rel="stylesheet" type="text/css" href="../css/styles.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
	<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
	<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-6872475020900549"
     crossorigin="anonymous"></script>
	<!--===============================================================================================-->
</head>

<body class="animsition" style="background-color: #f5f5f5;">

	<!-- Header -->
	<?php
	include '../templates/header-v2.php'
	?>

 <style>
	@-webkit-keyframes scroll {
		0% {
			transform: translateX(0);
		}

		100% {
			transform: translateX(calc(-250px * 7));
		}
	}

	@keyframes scroll {
		0% {
			transform: translateX(0);
		}

		100% {
			transform: translateX(calc(-250px * 7));
		}
	}

	.slider {
		background: white;
		box-shadow: 0 10px 20px -5px rgba(0, 0, 0, 0.125);
		height: 85px;
		margin: auto;
		overflow: hidden;
		position: relative;

	}

	.slider::before,
	.slider::after {
		background: linear-gradient(to right, white 0%, rgba(255, 255, 255, 0) 100%);
		content: "";
		height: 100px;
		position: absolute;
		width: 200px;
		z-index: 2;
	}

	.slider::after {
		right: 0;
		top: 0;
		transform: rotateZ(180deg);
	}

	.slider::before {
		left: 0;
		top: 0;
	}

	.slider .slide-track {
		-webkit-animation: scroll 40s linear infinite;
		animation: scroll 40s linear infinite;
		display: flex;
		width: calc(250px * 14);
	}

	.slider .slide {
		height: 100px;
	}
	.hov-btn2:hover{
	    background-color:#eea307;
	}
	.block2-pic{
	        width: auto!important;
    height: 270px;
    display: flex;
    background: white;
    justify-content: center;
	}
	.imagor{
	    background-color: white;
    object-fit: cover;
    width: auto!important;
    height: auto!important;
    margin: 25px;
	}
	.prodo{
	        color: #2e2e2e;
	}
	.block2-btn{
	    box-shadow: 0 0 8px rgba(0,0,0,0.8);
    font-weight: bold;
    color: #2e2e2e;
	}
	.block2-pic{
	        border-radius: 14px;
	}
	.imgc{
    object-fit: cover;
    width: auto;
    height: 300px;
	}
	.modal {
    display: none;
    position: fixed;
    z-index: 9999;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5); /* Color oscuro con transparencia */
}

.modal-content {
    background-color: #fefefe;
    margin: 10% auto;
    padding: 20px;
    border: 1px solid #888;
    width: 100%;
    animation-name: modalopen;
    animation-duration: 0.3s;
}
.block2-btn{
    cursor: pointer;
    color: black!important;
}
@keyframes modalopen {
    from {
        opacity: 0;
        transform: translateY(-50px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

</style>


<seccion>
<div>
 <?php
								$consulta = $conn->query("SELECT * FROM `BANER_PRO_MA` where id='1';");
								while ($fila = $consulta->fetch_array()) {
				?>   
    <img src="<?php echo $fila['img']; ?>" alt="" style="width: 100%;height: auto;">
    <?php } ?>
</div>
</seccion>

	<!-- Product -->
	<div class="m-t-23 p-b-140" style="background-color: #f5f5f5;">
		<div class="container">
		    <div class="p-b-10">
		        <?php
								$consulta = $conn->query("SELECT * FROM `BANER_PRO_MA` where id='1';");
								while ($fila = $consulta->fetch_array()) {
				?> 
				<h3 class="ltext-103 cl11">
					<?php echo $fila['titulo']; ?>
				</h3>
				<?php } ?>
			</div>
			<div class="flex-w flex-sb-m p-b-35">
			    <div style="box-shadow: rgb(0 0 0 / 14%) 0px 0px 5px 1px;background-color: #fff;">
			        
				<div class="flex-w flex-l-m filter-tope-group m-tb-10" style="margin: 10px;">
				    
					<button class="stext-106 cl11 hov1 bor3 trans-04 m-r-32 m-tb-5 how-active1" data-filter="*">
					<b>	Todo</b>
					</button>
					<?php
								$consulta = $conn->query("SELECT * FROM `tipo-productos`");
								while ($fila = $consulta->fetch_array()) {
				?>
					<button class="stext-106 cl11 hov1 bor3 trans-04 m-r-32 m-tb-5" data-filter=".<?php echo $fila['tipo']; ?>">
					 <b><?php echo $fila['icon']; ?> <?php echo $fila['nombre']; ?></b>
					</button>
					<?php } ?>
				</div>
            </div>
                
			</div>
<div class="p-b-10">
		        <?php
								$consulta = $conn->query("SELECT * FROM `BANER_PRO_MA` where id='1';");
								while ($fila = $consulta->fetch_array()) {
				?> 
				<h2 class="cl11" style="font-size: 1.15rem;    color: #333;
    font-family: Arial,Roboto,"-apple-system",Helvetica,sans-serif;
    font-weight: 700;"><b>
				    ¡LOS MEJORES PRODUCTOS! 🛒</b>

				</h2>
				<?php } ?>
			</div>
			<div class="row isotope-grid">
							
			<?php
								$consulta = $conn->query("SELECT p.id,p.producto,p.imagen,p.id_tipo,t.tipo,t.nombre,p.nombre_clave,m.img_marca FROM `productos` as p INNER JOIN `tipo-productos` as t ON p.id_tipo = t.id INNER JOIN `marcas` as m ON p.id_marca = m.id ORDER BY RAND()");
								while ($fila = $consulta->fetch_array()) {
				?>
			
			<div class="col-sm-6 col-md-4 col-lg-3 p-b-35 isotope-item <?php echo $fila['tipo']; ?>">
								<!-- Block2 -->
								<div class="block2">
									<div class="block2-pic hov-img0" style="box-shadow: rgb(0 0 0 / 14%) 0px 0px 5px 1px;">
									<img style="z-index: 1;position: absolute; top: 6px;right: 10px;width: 20%;" src="<?php echo $fila['img_marca']; ?>" alt="IMG-PRODUCT" >
										<img style="z-index: 1;position: absolute; top: 6px;left: 4px;width: 30%;" src="https://www.gyrglobalelectric.com/images/d60966d3.svg" alt="IMG-PRODUCT" >
										
									        	<img class="imagor" style="background-color: white;" src="<?php echo $fila['imagen']; ?>" alt="IMG-PRODUCT" >


									<a style="box-shadow: 0 0 8px rgba(0,0,0,0.8);" class="block2-btn flex-c-m stext-103 cl2 size-102 bg0 bor2 hov-btn2 p-lr-15 trans-04 btn-outline-dark" data-modal-target="<?php echo $fila['nombre_clave']; ?>">Ver producto</a>

									</div>

									<div class="block2-txt flex-w flex-t p-t-14">
										<div class="block2-txt-child1 flex-col-l ">
											<a href="#" class="prodo" data-bs-toggle="modal" data-bs-target="#<?php echo $fila['nombre_clave']; ?>">
											<b><?php echo $fila['producto']; ?></b>
											</a>

											
										</div>


									</div>
								</div>
							</div>
			
			<?php } ?>
</div>

		</div>
	</div>


	<!-- Footer -->

	<?php
	include '../templates/footer.php'
	?>

	<!-- Back to top -->
	<div class="btn-back-to-top" id="myBtn">
		<span class="symbol-btn-back-to-top">
			<i class="zmdi zmdi-chevron-up"></i>
		</span>
	</div>




	<?php
								$consulta = $conn->query("SELECT p.id,p.producto,p.imagen,p.id_tipo,t.tipo,t.nombre,p.nombre_clave,p.descripcion FROM `productos` as p INNER JOIN `tipo-productos` as t ON p.id_tipo = t.id ");
								while ($fila = $consulta->fetch_array()) {
				?>

	<div class="modal fade js-modal1 p-t-60 p-b-20" id="<?php echo $fila['nombre_clave']; ?>">

		<style>
			@media (min-width: 576px) {
				.modal-dialog {
					max-width: 70%;
					margin: 100px auto;
				}
			}
		</style>

		<div class="modal-dialog">
			<div class="modal-content">

				<?php
				include '../templates/descripcion.php'
				?>
			</div>
		</div>
	</div>
	<?php } ?>



<script>
document.addEventListener('DOMContentLoaded', function () {
    const modalButtons = document.querySelectorAll('[data-modal-target]');
    const modals = document.querySelectorAll('.modal');
    const closeButtons = document.querySelectorAll('.js-hide-modal1');

    modalButtons.forEach(button => {
        button.addEventListener('click', () => {
            const targetModalId = button.getAttribute('data-modal-target');
            const targetModal = document.getElementById(targetModalId);

            if (targetModal) {
                targetModal.style.display = 'block';
                setTimeout(() => {
                    targetModal.classList.add('show');
                    document.body.style.overflow = 'hidden';
                }, 10);
            }
        });
    });

    closeButtons.forEach(closeButton => {
        closeButton.addEventListener('click', () => {
            const targetModalId = closeButton.getAttribute('data-modal-target');
            const targetModal = document.getElementById(targetModalId);

            if (targetModal) {
                targetModal.classList.remove('show');
                setTimeout(() => {
                    targetModal.style.display = 'none';
                    document.body.style.overflow = 'auto';
                }, 300);
            }
        });
    });

    modals.forEach(modal => {
        modal.addEventListener('click', (event) => {
            if (event.target === modal) {
                modal.classList.remove('show');
                setTimeout(() => {
                    modal.style.display = 'none';
                    document.body.style.overflow = 'auto';
                }, 300);
            }
        });
    });
});


</script>

	<!--===============================================================================================-->
	<script src="../vendor/jquery/jquery-3.2.1.min.js"></script>
	<!--===============================================================================================-->
	<script src="../vendor/animsition/js/animsition.min.js"></script>
	<!--===============================================================================================-->
	<script src="../vendor/bootstrap/js/popper.js"></script>
	<script src="../vendor/bootstrap/js/bootstrap.min.js"></script>
	<!--===============================================================================================-->
	<script src="../vendor/select2/select2.min.js"></script>
	<script>
		$(".js-select2").each(function() {
			$(this).select2({
				minimumResultsForSearch: 20,
				dropdownParent: $(this).next('.dropDownSelect2')
			});
		})
	</script>
	<!--===============================================================================================-->

	<script src="../vendor/daterangepicker/moment.min.js"></script>
	<script src="../vendor/daterangepicker/daterangepicker.js"></script>
	<!--===============================================================================================-->
	<script src="../vendor/slick/slick.min.js"></script>
	<script src="../js/slick-custom.js"></script>
	<!--===============================================================================================-->
	<script src="../vendor/parallax100/parallax100.js"></script>
	<script>
		$('.parallax100').parallax100();
	</script>
	<!--===============================================================================================-->
	<script src="../vendor/MagnificPopup/jquery.magnific-popup.min.js"></script>
	<script>
		$('.gallery-lb').each(function() { // the containers for all your galleries
			$(this).magnificPopup({
				delegate: 'a', // the selector for gallery item
				type: 'image',
				gallery: {
					enabled: true
				},
				mainClass: 'mfp-fade'
			});
		});
	</script>
	<!--===============================================================================================-->
	<script src="../vendor/isotope/isotope.pkgd.min.js"></script>
	<!--===============================================================================================-->
	<script src="../vendor/sweetalert/sweetalert.min.js"></script>
	<script>
		$('.js-addwish-b2, .js-addwish-detail').on('click', function(e) {
			e.preventDefault();
		});

		$('.js-addwish-b2').each(function() {
			var nameProduct = $(this).parent().parent().find('.js-name-b2').php();
			$(this).on('click', function() {
				swal(nameProduct, "is added to wishlist !", "success");

				$(this).addClass('js-addedwish-b2');
				$(this).off('click');
			});
		});

		$('.js-addwish-detail').each(function() {
			var nameProduct = $(this).parent().parent().parent().find('.js-name-detail').php();

			$(this).on('click', function() {
				swal(nameProduct, "is added to wishlist !", "success");

				$(this).addClass('js-addedwish-detail');
				$(this).off('click');
			});
		});

		/*---------------------------------------------*/

		$('.js-addcart-detail').each(function() {
			var nameProduct = $(this).parent().parent().parent().parent().find('.js-name-detail').php();
			$(this).on('click', function() {
				swal(nameProduct, "is added to cart !", "success");
			});
		});
	</script>
	<!--===============================================================================================-->
	<script src="../vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
	<script>
		$('.js-pscroll').each(function() {
			$(this).css('position', 'relative');
			$(this).css('overflow', 'hidden');
			var ps = new PerfectScrollbar(this, {
				wheelSpeed: 1,
				scrollingThreshold: 1000,
				wheelPropagation: false,
			});

			$(window).on('resize', function() {
				ps.update();
			})
		});
	</script>
	<!--===============================================================================================-->
	<script src="../js/main.js"></script>

</body>

</html>