<?php
$servidor = "mysql:dbname=u217227092_crud;host=localhost";
$usuario = "u217227092_crud";
$password = "7249ZagPrad";

try {
    $pdo = new PDO($servidor, $usuario, $password, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Obtener lista de usuarios
    $stmt = $pdo->prepare("SELECT * FROM usuarios");
    $stmt->execute();
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Construir la tabla de usuarios
    $tabla_usuarios = '<table class="table table-striped">';
    $tabla_usuarios .= '<tr><th>Imagen</th><th>Nombre</th><th>Apellido</th><th>Email</th><th>Teléfono</th><th>Fecha de Nacimiento</th><th>Acciones</th></tr>';
    foreach ($result as $row) {
       $tabla_usuarios .= '<tr><td><img style="height: 50px;width: 50px;object-fit: cover;" src="'.$row['fotografia'].'" alt="Usuario"/></td><td>'.$row['nombre'].'</td><td>'.$row['apellido'].'</td><td>'.$row['email'].'</td><td>'.$row['telefono'].'</td><td>'.$row['fechanacimiento'].'</td><td><button data-id="'.$row['id'].'" class="btn btn-danger eliminar-usuario-btn">Eliminar</button></td></tr>';

    }
    $tabla_usuarios .= '</table>';
    
    echo $tabla_usuarios;
} catch (PDOException $e) {
    echo "Error al cargar usuarios: " . $e->getMessage();
}
?>
