<?php
$servidor = "mysql:dbname=u217227092_crud;host=localhost";
$usuario = "u217227092_crud";
$password = "7249ZagPrad";

try {
    $pdo = new PDO($servidor, $usuario, $password, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Obtener ID del usuario a eliminar
    $idUsuario = $_POST['id'];

    // Obtener la ruta de la fotografía del usuario
    $stmt = $pdo->prepare("SELECT fotografia FROM usuarios WHERE id = :id");
    $stmt->bindParam(':id', $idUsuario, PDO::PARAM_INT);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $rutaFotografia = $result['fotografia'];

    // Eliminar el registro de la base de datos
    $stmt = $pdo->prepare("DELETE FROM usuarios WHERE id = :id");
    $stmt->bindParam(':id', $idUsuario, PDO::PARAM_INT);
    $stmt->execute();

    // Borrar la fotografía del servidor
    unlink($rutaFotografia);

    // Respuesta JSON para indicar éxito
    echo json_encode(array('success' => true));
} catch (PDOException $e) {
    // En caso de error, enviar una respuesta JSON con el error
    echo json_encode(array('success' => false, 'error' => $e->getMessage()));
}
?>
