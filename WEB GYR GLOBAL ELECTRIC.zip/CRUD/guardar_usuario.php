<?php
$servidor = "mysql:dbname=u217227092_crud;host=localhost";
$usuario = "u217227092_crud";
$password = "7249ZagPrad";

try {
    $pdo = new PDO($servidor, $usuario, $password, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Procesar los datos del formulario
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $email = $_POST['email'];
    $telefono = $_POST['telefono'];
    $fecha_nacimiento = $_POST['fechanacimiento'];

    // Guardar la fotografía
    $fotografia = $_FILES['fotografia']['name'];
    $fotografia_temp = $_FILES['fotografia']['tmp_name'];
    $fotografia_destino = "fotografias/" . $fotografia;
    move_uploaded_file($fotografia_temp, $fotografia_destino);

    // Insertar los datos en la base de datos
    $stmt = $pdo->prepare("INSERT INTO usuarios (nombre, apellido, email, telefono, fechanacimiento, fotografia) VALUES (:nombre, :apellido, :email, :telefono, :fechanacimiento, :fotografia)");
    $stmt->bindParam(':nombre', $nombre);
    $stmt->bindParam(':apellido', $apellido);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':telefono', $telefono);
    $stmt->bindParam(':fechanacimiento', $fecha_nacimiento);
    $stmt->bindParam(':fotografia', $fotografia_destino);
    $stmt->execute();

    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'Error al insertar los datos en la base de datos: ' . $e->getMessage()]);
}
?>
