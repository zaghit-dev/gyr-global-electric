<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD de Usuarios</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
           <style>
           .list-wrapper {
    max-width: 800px;
    width: 800px;
    height: 90%;
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 10px;
    margin-top: 20px;
    overflow-x: auto;
}
        .error-message {
            color: red;
            font-size: 12px;
        }

        form label, .form input, .form select {
            display: block;
            margin-bottom: 10px;
        }
form input{
        width: 100%;

}
        .form-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .form-wrapper {
                max-width: 450px;

            width: 100%;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
        }

        @media (max-width: 767px) {
            .form-wrapper {
                max-width: 100%;
            }
        }





@media (max-width: 767px) {
    .list-wrapper {
        max-width: 100%;
        margin-top: 20px;
    }
}
    </style>
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-5">
            <div class="form-container">
                <div class="form-wrapper">
                    <h2 class="text-center">Registrar Usuario CRUD</h2>
                    <form id="registro-form" enctype="multipart/form-data" onsubmit="return validarelForm()">
                        <label for="nombre">Nombre:</label>
                        <input type="text" id="nombre" name="nombre" required>

                        <label for="apellido">Apellido:</label>
                        <input type="text" id="apellido" name="apellido" required>

                        <label for="email">Email:</label>
                        <input type="email" id="email" name="email" required>
                        <span id="email-error" class="error-message"></span>

                        <label for="telefono">Teléfono:</label>
                        <input type="tel" id="telefono" name="telefono" required>
                        <span id="telefono-error" class="error-message"></span>

                        <label for="fecha_nacimiento">Fecha de Nacimiento:</label>
                        <input type="date" id="fecha_nacimiento" name="fechanacimiento" required>

                        <label for="fotografia">Fotografía:</label>
                        <input type="file" id="fotografia" name="fotografia" accept="image/*" required>
                        <div style="display: flex; justify-content: center;">
                            <img id="preview" src="#" alt="Vista previa de la imagen"
                                 style="width: 150px; height: 150px; object-fit: cover; border-radius: 100%; display: none;">
                        </div>
                        <br><br>

                        <input type="submit" value="Registrar" class="btn btn-primary">
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-7">
            <div class="list-wrapper">
                <div id="lista-usuarios">
                    <!-- Aquí va la tabla de usuarios -->
                </div>
            </div>
        </div>
    </div>
</div>
    </div>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
$(document).ready(function() {
    // Función para cargar la lista de usuarios
    function cargarUsuarios() {
        $.ajax({
            url: 'cargar_usuarios.php',
            type: 'GET',
            dataType: 'html',
            success: function(response) {
                $('#lista-usuarios').html(response);
            },
            error: function(xhr, status, error) {
                console.error(xhr.responseText);
            }
        });
    }

    // Cargar lista de usuarios al cargar la página
    cargarUsuarios();

    // Actualizar lista de usuarios cada 5 segundos
    setInterval(function() {
        cargarUsuarios();
    }, 5000); // 5000 milisegundos = 5 segundos

// Función para eliminar varios usuarios
$(document).on('click', '.eliminar-usuario-btn', function() {
    var idUsuario = $(this).data('id');
    if (confirm('¿Estás seguro de que quieres eliminar este usuario?')) {
        $.ajax({
            url: 'eliminar_usuario.php',
            type: 'POST',
            data: {id: idUsuario},
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    cargarUsuarios(); // Recargar la lista de usuarios después de eliminar
                } else {
                    alert('Error al eliminar el usuario: ' + response.error);
                }
            },
            error: function(xhr, status, error) {
                console.error(xhr.responseText);
            }
        });
    }
});



    $('#registro-form').submit(function(event) {
        event.preventDefault(); // Evitar que se recargue la página
        let formData = new FormData(this);

        $.ajax({
            url: 'guardar_usuario.php',
            type: 'POST',
            data: formData,
            dataType: 'json',
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.success) {
                    // Actualizar la tabla de usuarios si la inserción fue exitosa
                    $('#lista-usuarios').html(response.tabla);
                    // Limpiar el formulario
                    $('#registro-form')[0].reset();
                } else {
                    // Mostrar mensaje de error
                    alert('Error al registrar el usuario: ' + response.error);
                }
            },
            error: function(xhr, status, error) {
                console.error(xhr.responseText);
            }
        });
    });
});


    </script>
    <script>
  document.getElementById("email").addEventListener("input", function() {
    const email = this.value;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!emailRegex.test(email)) {
        document.getElementById("email-error").textContent = "Por favor ingresa un correo electrónico válido.";
        this.style.border = "2px solid red";
        document.getElementById("submit-button").disabled = true;
    } else {
        document.getElementById("email-error").textContent = "";
        this.style.border = "1px solid #ccc";
        document.getElementById("submit-button").disabled = false;
    }
});

document.getElementById("telefono").addEventListener("input", function() {
    const telefono = this.value;
    const telefonoRegex = /^\d+$/;

    if (!telefonoRegex.test(telefono)) {
        document.getElementById("telefono-error").textContent = "Por favor ingresa un teléfono válido.";
        this.style.border = "2px solid red";
        this.value = ""; 
    } else {
        document.getElementById("telefono-error").textContent = "";
        this.style.border = "1px solid #ccc";
    }
});

function validarelForm() {
    const email = document.getElementById("email").value;
    const telefono = document.getElementById("telefono").value;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const telefonoRegex = /^\d+$/;

    if (!emailRegex.test(email)) {
        document.getElementById("email-error").textContent = "Por favor ingresa un correo electrónico válido.";
        document.getElementById("email").style.border = "2px solid red";
        document.getElementById("submit-button").disabled = true; 
        return false;
    } else {
        document.getElementById("email-error").textContent = "";
        document.getElementById("email").style.border = "1px solid #ccc";
    }

    if (!telefonoRegex.test(telefono)) {
        document.getElementById("telefono-error").textContent = "Por favor ingresa un teléfono válido.";
        document.getElementById("telefono").style.border = "2px solid red";
        return false;
    } else {
        document.getElementById("telefono-error").textContent = "";
        document.getElementById("telefono").style.border = "1px solid #ccc";
    }

    return true;
}

document.getElementById("fotografia").addEventListener("change", function() {
    const file = this.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            document.getElementById("preview").src = e.target.result;
            document.getElementById("preview").style.display = "block";
        }
        reader.readAsDataURL(file);
    } else {
        document.getElementById("preview").src = "#";
        document.getElementById("preview").style.display = "none";
    }
});


    </script>
</body>
</html>
