<?php
/*******************************************
 * 1. CONFIGURACIÓN DE BASE DE DATOS (PDO) *
 *******************************************/
// Datos de conexión (ajustar a la configuración real)
$dbHost = "localhost";
$dbName = "u217227092_global";     // Nombre de la base de datos
$dbUser = "u217227092_global";  // Usuario de la base de datos
$dbPass = "7249Global"; // Password de la base de datos

try {
    $dsn = "mysql:host=$dbHost;dbname=$dbName;charset=utf8mb4";
    // Crear objeto PDO con opciones seguras (modo excepciones, sin emulación)
    $pdo = new PDO($dsn, $dbUser, $dbPass, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
} catch (PDOException $e) {
    die("Error de conexión a la base de datos: " . $e->getMessage());
}

// Tabla asumida: images (id INT AI PK, filename VARCHAR, filepath VARCHAR, upload_date DATETIME, filters VARCHAR)

/*******************************************************
 * 2. MANEJO DE SUBIDA DE IMAGEN (guardar archivo y DB) *
 *******************************************************/
$imageData = null;    // Datos de imagen para usar en la vista (ruta y posiblemente ID)
$processedPath = null; // Ruta de imagen procesada (con fondo quitado y borde)

// Comprobar si se envió un archivo por el formulario
if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
    $fileTmp   = $_FILES['imagen']['tmp_name'];
    $fileName  = $_FILES['imagen']['name'];      // nombre original del archivo
    $fileSize  = $_FILES['imagen']['size'];
    $fileError = $_FILES['imagen']['error'];

    // Validación básica del archivo subido
    $allowedExt = ['jpg','jpeg','png','gif'];
    $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
    // Verificar extensión permitida y que realmente sea una imagen
    $isImage = @getimagesize($fileTmp);
    if (!$isImage || !in_array($fileExt, $allowedExt)) {
        die("El archivo subido no es una imagen válida.");
    }

    // Crear directorio uploads/ si no existe
    $uploadDir = __DIR__ . "/uploads";
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755);
    }

    // Generar un nombre único para evitar colisiones (sin espacios ni caracteres raros)
    $uniqueName = bin2hex(random_bytes(8));  // 16 caracteres hex aleatorios
    $origFilePath = "$uploadDir/$uniqueName.$fileExt";   // ruta completa para original

    // Mover el archivo subido desde el directorio temporal a nuestra carpeta
    if (!move_uploaded_file($fileTmp, $origFilePath)) {
        die("Error al mover el archivo subido.");
    }

    // Guardar metadatos en la base de datos
    $insertSql = "INSERT INTO images (filename, filepath, upload_date, filters) VALUES (:fname, :fpath, NOW(), :filters)";
    $stmt = $pdo->prepare($insertSql);
    $origNameForDB = basename($fileName);
    $initialFilters = "none";  // inicialmente ningún filtro permanente
    $stmt->bindParam(':fname', $origNameForDB);
    $stmt->bindParam(':fpath', $dbFilePath);  // Ruta relativa/abreviada para DB
    $stmt->bindParam(':filters', $initialFilters);
    // Podemos almacenar solo la ruta relativa (por ejemplo "uploads/unique.png") en la DB:
    $dbFilePath = "uploads/$uniqueName.png";  // guardaremos ruta del procesado final (png)
    // Nota: asumiremos que el procesado será PNG, por lo que almacenamos .png independientemente de la extensión original.
    $stmt->execute();

    $imageId = $pdo->lastInsertId();  // ID asignado en la base de datos

    // 3. PROCESAMIENTO DE IMAGEN CON IMAGICK (quitar fondo y agregar borde)
    try {
        $imagick = new Imagick($origFilePath);
        // Asegurar canal alfa y formato PNG para soportar transparencia
        $imagick->setImageFormat('png');                        // cambiar formato a PNG
        $imagick->setImageAlphaChannel(Imagick::ALPHACHANNEL_SET);  // habilitar canal alfa (todo opaco inicialmente)

        // Obtener color de fondo asumiendo que el pixel (0,0) es fondo
        $bgColor = $imagick->getImagePixelColor(0, 0);  // ImagickPixel del color del fondo
        // Hacer transparente el color de fondo (con una tolerancia fuzz, ej. 10% del rango cuántico)
        $fuzz = 0.1 * $imagick->getQuantumRange()['quantumRangeLong'];  // 10% del máximo (Quantum) como tolerancia
        $imagick->transparentPaintImage($bgColor, 0.0, $fuzz, false);
        // (Si el fondo es exactamente uniforme y distinto del sujeto, fuzz podría ser 0&#8203;:contentReference[oaicite:12]{index=12}. 
        // Se usa un pequeño fuzz para cubrir sombras leves. Para casos complejos ver técnica de flood fill&#8203;:contentReference[oaicite:13]{index=13}).

        // Recortar bordes transparentes sobrantes alrededor del sujeto
        $imagick->trimImage(0);  // recorta los bordes del color de fondo (ahora transparente)&#8203;:contentReference[oaicite:14]{index=14}

        // Agregar un borde decorativo de color (ejemplo: color azul de 10px de grosor)
        $borderColor = new ImagickPixel("blue");
        $imagick->borderImage($borderColor, 10, 10);  // agrega borde de 10px en cada lado&#8203;:contentReference[oaicite:15]{index=15}

        // Guardar la imagen procesada en el servidor (formato PNG)
        $processedPath = "$uploadDir/$uniqueName.png";
        $imagick->writeImage($processedPath);
        $imagick->clear();
        $imagick->destroy();

        // Actualizar la ruta almacenada en DB (ya habíamos establecido .png en $dbFilePath)
        // Si se desea, podríamos usar UPDATE para confirmar ruta final, pero en este caso $dbFilePath ya era con .png

    } catch (ImagickException $e) {
        die("Error procesando la imagen con Imagick: " . $e->getMessage());
    }

    // Preparar datos para mostrar en la página
    $imageData = [
        'id'   => $imageId,
        'path' => $dbFilePath  // ruta relativa para usar en <img src>, por ejemplo "uploads/xyz.png"
    ];
}

// 4. APLICAR FILTROS (NEGATIVO / BLANCO Y NEGRO) SI SE SOLICITA
if (isset($_POST['filter']) && isset($_POST['image_id'])) {
    $filterType = $_POST['filter'];   // "neg" o "bw"
    $imgId      = (int)$_POST['image_id'];

    // Obtener la ruta del archivo de imagen desde la base de datos según el ID
    $stmt = $pdo->prepare("SELECT filepath FROM images WHERE id = :id");
    $stmt->bindParam(':id', $imgId, PDO::PARAM_INT);
    $stmt->execute();
    $row = $stmt->fetch();
    if ($row) {
        $fileRelPath = $row['filepath'];              // p.ej. "uploads/unique.png"
        $fileFullPath = __DIR__ . "/" . $fileRelPath; // ruta absoluta para abrir con Imagick

        try {
            $imagick = new Imagick($fileFullPath);
            // Aplicar el filtro seleccionado
            if ($filterType === 'neg') {
                // Filtro negativo: invierte colores de la imagen
                $imagick->negateImage(false);  // false => invertir todos los colores&#8203;:contentReference[oaicite:16]{index=16}
            } elseif ($filterType === 'bw') {
                // Filtro blanco y negro: convertir a escala de grises
                $imagick->setImageType(Imagick::IMGTYPE_GRAYSCALEMATTE);
                // Alternativa: $imagick->modulateImage(100, 0, 100);
                // Usamos GRAYSCALEMATTE para conservar transparencia&#8203;:contentReference[oaicite:17]{index=17}.
            }
            // Guardar la imagen filtrada temporalmente y preparar para mostrar
            $filteredName = $imgId . "_filtered.png";
            $filteredPath = __DIR__ . "/uploads/$filteredName";
            $imagick->writeImage($filteredPath);
            $imagick->clear();
            $imagick->destroy();
            // Indicar a la página que muestre esta imagen filtrada en lugar de la original procesada
            $imageData = [
                'id'   => $imgId,
                'path' => "uploads/$filteredName",
                'filtered' => true,
                'filterType' => $filterType
            ];
            // Nota: En una implementación real, podríamos no guardar en disco sino enviar directamente al navegador.
            // Aquí guardamos para simplificar la visualización en <img>.
        } catch (ImagickException $e) {
            die("Error al aplicar filtro con Imagick: " . $e->getMessage());
        }
    } else {
        echo "Imagen no encontrada en la base de datos.";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Subir imagen de mascota y aplicar filtros</title>
    <style>
        /* CSS mínimo para mejorar la visualización */
        body { font-family: Arial, sans-serif; margin: 20px; text-align: center; }
        .preview-img { max-width: 100%; border: 2px solid #ccc; }
        .buttons { margin: 10px; }
    </style>
</head>
<body>
    <h2>Subir imagen de mascota</h2>
    <!-- Formulario para subir la imagen -->
    <form method="post" enctype="multipart/form-data">
        <input type="file" name="imagen" accept="image/*" required>
        <button type="submit">Subir Imagen</button>
    </form>

<?php if ($imageData): ?>
    <hr>
    <h3>Imagen subida<?= !empty($imageData['filtered']) ? " (filtro aplicado)" : "" ?>:</h3>
    <!-- Mostrar la imagen procesada (y filtrada si corresponde) -->
    <img class="preview-img" src="<?= htmlspecialchars($imageData['path']) ?>" alt="Imagen de mascota procesada">
    <p>
        <?php if (!empty($imageData['filtered'])): 
            // Mostrar texto del filtro aplicado
            if ($imageData['filterType'] === 'neg') {
                echo "Filtro aplicado: Negativo";
            } elseif ($imageData['filterType'] === 'bw') {
                echo "Filtro aplicado: Blanco y Negro";
            }
        else: 
            echo "Imagen sin filtro (puede aplicar uno abajo)";
        endif; ?>
    </p>
    <!-- Botones para aplicar filtros (negativo o B/N) -->
    <div class="buttons">
        <form method="post">
            <!-- Incluir el ID de imagen para saber a cuál aplicar el filtro -->
            <input type="hidden" name="image_id" value="<?= htmlspecialchars($imageData['id']) ?>">
            <button type="submit" name="filter" value="neg">Aplicar Negativo</button>
            <button type="submit" name="filter" value="bw">Aplicar Blanco/Negro</button>
        </form>
    </div>
    <!-- Nota: tras aplicar un filtro, se muestra la imagen filtrada.
              El original sigue almacenado sin cambios y puede re-aplicar otros filtros. -->
<?php endif; ?>

</body>
</html>