<?php
require("../global/conexion.php");
?>
<!DOCTYPE html>
<html lang="es">

<head>
	<title>Marcas - G&R GLOBAL ELECTRIC SOLUCION INDUSTRIAL</title>
	<meta charset="UTF-8">
	<meta name="facebook-domain-verification" content="5kc9dwkxslrcusfyn7nh9upwp32u59" />
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!--===============================================================================================-->
	<?php
								$consulta = $conn->query("SELECT * FROM `logo` where id='1'");
								while ($fila = $consulta->fetch_array()) {
				?>
	<link rel="icon" type="image/png" href="<?php echo $fila['logo']; ?>"/>
	<?php } ?>
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendor/bootstrap/css/bootstrap.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../fonts/iconic/css/material-design-iconic-font.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../fonts/linearicons-v1.0.0/icon-font.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendor/animate/animate.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendor/css-hamburgers/hamburgers.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendor/animsition/css/animsition.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendor/select2/select2.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendor/daterangepicker/daterangepicker.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendor/slick/slick.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendor/MagnificPopup/magnific-popup.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendor/perfect-scrollbar/perfect-scrollbar.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../icons.css">

	<link rel="stylesheet" type="text/css" href="../css/util.css">
	<link rel="stylesheet" type="text/css" href="../css/styles.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
	<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
	<!--===============================================================================================-->
</head>

<body class="animsition" style="background-color: #f5f5f5;">

	<!-- Header -->
	<?php
	include '../templates/header-v2.php'
	?>

 <style>
	@-webkit-keyframes scroll {
		0% {
			transform: translateX(0);
		}

		100% {
			transform: translateX(calc(-250px * 7));
		}
	}

	@keyframes scroll {
		0% {
			transform: translateX(0);
		}

		100% {
			transform: translateX(calc(-250px * 7));
		}
	}

	.slider {
		background: white;
		box-shadow: 0 10px 20px -5px rgba(0, 0, 0, 0.125);
		height: 85px;
		margin: auto;
		overflow: hidden;
		position: relative;

	}

	.slider::before,
	.slider::after {
		background: linear-gradient(to right, white 0%, rgba(255, 255, 255, 0) 100%);
		content: "";
		height: 100px;
		position: absolute;
		width: 200px;
		z-index: 2;
	}

	.slider::after {
		right: 0;
		top: 0;
		transform: rotateZ(180deg);
	}

	.slider::before {
		left: 0;
		top: 0;
	}

	.slider .slide-track {
		-webkit-animation: scroll 40s linear infinite;
		animation: scroll 40s linear infinite;
		display: flex;
		width: calc(250px * 14);
	}

	.slider .slide {
		height: 100px;
	}
</style>

<seccion>
<div>
 <?php
								$consulta = $conn->query("SELECT * FROM `BANER_PRO_MA` where id='2';");
								while ($fila = $consulta->fetch_array()) {
				?>   
    <img src="<?php echo $fila['img']; ?>" alt="" style="width: 100%;height: auto;">
    <?php } ?>
</div>
</seccion>

	<!-- Product -->
	<div class="m-t-23 p-b-140" style="background-color: #f5f5f5;">
		<div class="container">
		    <div class="p-b-10">
		        <?php
								$consulta = $conn->query("SELECT * FROM `BANER_PRO_MA` where id='2';");
								while ($fila = $consulta->fetch_array()) {
				?> 
				<h3 class="ltext-103 cl11">
					<?php echo $fila['titulo']; ?>
				</h3>
				<?php } ?>
			</div>
			<div class="flex-w flex-sb-m p-b-52">
			    <div style="box-shadow: rgb(0 0 0 / 14%) 0px 0px 5px 1px;background-color: #fff;">
			        
				<div class="flex-w flex-l-m filter-tope-group m-tb-10" style="margin: 10px;">
				    
					<button class="stext-106 cl11 hov1 bor3 trans-04 m-r-32 m-tb-5 how-active1" data-filter="*">
					<b>	Todo</b>
					</button>
					<?php
								$consulta = $conn->query("SELECT * FROM `marcas`");
								while ($fila = $consulta->fetch_array()) {
				?>
					<button class="stext-106 cl11 hov1 bor3 trans-04 m-r-32 m-tb-5" data-filter=".<?php echo $fila['marca']; ?>">
					 <b><?php echo $fila['marca']; ?></b>
					</button>
					<?php } ?>
				</div>
            </div>

			</div>

			<div class="row isotope-grid">
							
			<?php
								$consulta = $conn->query("SELECT * FROM `marcas` ORDER BY RAND();");
								while ($fila = $consulta->fetch_array()) {
				?>
			
			<div class="col-sm-6 col-md-4 col-lg-3 p-b-35 isotope-item <?php echo $fila['marca']; ?>">
								<!-- Block2 -->
								<div class="block2">
									<div class="block2-pic hov-img0" style="box-shadow: rgb(0 0 0 / 14%)  0px 0px 5px 1px;background-color: white;padding: 50px;">
									    
										<img style="z-index: 1;position: absolute; top: 6px;left: 4px;width: 30%;" src="https://i.postimg.cc/QCP2fWPy/d60966d3-54d3-444a-b720-110e5a33024c-auto-x2-removebg-preview.png" alt="IMG-PRODUCT" >
										
									        	<img style="background-color: white;padding-top: 30%;" src="<?php echo $fila['img_marca']; ?>" alt="IMG-PRODUCT" >

									</div>

									<div class="block2-txt flex-w flex-t p-t-14">
										<div class="block2-txt-child1 flex-col-l ">
											<a data-bs-toggle="modal">
											<b><?php echo $fila['marca']; ?></b>
											</a>

											
										</div>


									</div>
								</div>
							</div>
			
			<?php } ?>
</div>

		</div>
	</div>


	<!-- Footer -->

	<?php
	include '../templates/footer.php'
	?>

	<!-- Back to top -->
	<div class="btn-back-to-top" id="myBtn">
		<span class="symbol-btn-back-to-top">
			<i class="zmdi zmdi-chevron-up"></i>
		</span>
	</div>




	<!--===============================================================================================-->
	<script src="../vendor/jquery/jquery-3.2.1.min.js"></script>
	<!--===============================================================================================-->
	<script src="../vendor/animsition/js/animsition.min.js"></script>
	<!--===============================================================================================-->
	<script src="../bootstrap/js/popper.js"></script>
	<script src="../vendor/bootstrap/js/bootstrap.min.js"></script>
	<!--===============================================================================================-->
	<script src="../vendor/select2/select2.min.js"></script>
	<script>
		$(".js-select2").each(function() {
			$(this).select2({
				minimumResultsForSearch: 20,
				dropdownParent: $(this).next('.dropDownSelect2')
			});
		})
	</script>
	<!--===============================================================================================-->

	<script src="../vendor/daterangepicker/moment.min.js"></script>
	<script src="../vendor/daterangepicker/daterangepicker.js"></script>
	<!--===============================================================================================-->
	<script src="../vendor/slick/slick.min.js"></script>
	<script src="../js/slick-custom.js"></script>
	<!--===============================================================================================-->
	<script src="../vendor/parallax100/parallax100.js"></script>
	<script>
		$('.parallax100').parallax100();
	</script>
	<!--===============================================================================================-->
	<script src="../vendor/MagnificPopup/jquery.magnific-popup.min.js"></script>
	<script>
		$('.gallery-lb').each(function() { // the containers for all your galleries
			$(this).magnificPopup({
				delegate: 'a', // the selector for gallery item
				type: 'image',
				gallery: {
					enabled: true
				},
				mainClass: 'mfp-fade'
			});
		});
	</script>
	<!--===============================================================================================-->
	<script src="../vendor/isotope/isotope.pkgd.min.js"></script>
	<!--===============================================================================================-->
	<script src="../vendor/sweetalert/sweetalert.min.js"></script>
	<script>
		$('.js-addwish-b2, .js-addwish-detail').on('click', function(e) {
			e.preventDefault();
		});

		$('.js-addwish-b2').each(function() {
			var nameProduct = $(this).parent().parent().find('.js-name-b2').php();
			$(this).on('click', function() {
				swal(nameProduct, "is added to wishlist !", "success");

				$(this).addClass('js-addedwish-b2');
				$(this).off('click');
			});
		});

		$('.js-addwish-detail').each(function() {
			var nameProduct = $(this).parent().parent().parent().find('.js-name-detail').php();

			$(this).on('click', function() {
				swal(nameProduct, "is added to wishlist !", "success");

				$(this).addClass('js-addedwish-detail');
				$(this).off('click');
			});
		});

		/*---------------------------------------------*/

		$('.js-addcart-detail').each(function() {
			var nameProduct = $(this).parent().parent().parent().parent().find('.js-name-detail').php();
			$(this).on('click', function() {
				swal(nameProduct, "is added to cart !", "success");
			});
		});
	</script>
	<!--===============================================================================================-->
	<script src="../vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
	<script>
		$('.js-pscroll').each(function() {
			$(this).css('position', 'relative');
			$(this).css('overflow', 'hidden');
			var ps = new PerfectScrollbar(this, {
				wheelSpeed: 1,
				scrollingThreshold: 1000,
				wheelPropagation: false,
			});

			$(window).on('resize', function() {
				ps.update();
			})
		});
	</script>
	<!--===============================================================================================-->
	<script src="../js/main.js"></script>

</body>

</html>