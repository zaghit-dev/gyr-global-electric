<?php
// api/tipos.php - API para gestionar tipos de productos
session_start();

// Verificar que el usuario esté logueado
if (!isset($_SESSION['usuario_id'])) {
    header('HTTP/1.1 401 Unauthorized');
    echo json_encode(['error' => 'No autorizado']);
    exit;
}

require_once '../config.php';

// Obtener la conexión a la base de datos
$db = conectarDB();

// Solo implementamos el método GET para obtener tipos
$query = "SELECT * FROM `tipo-productos` ORDER BY nombre ASC";
$stmt = $db->prepare($query);
$stmt->execute();
$tipos = $stmt->fetchAll();

echo json_encode($tipos);
?>

