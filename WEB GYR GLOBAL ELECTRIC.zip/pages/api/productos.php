<?php
// api/productos.php - API para gestionar productos
session_start();

// Verificar que el usuario esté logueado
if (!isset($_SESSION['usuario_id'])) {
    header('HTTP/1.1 401 Unauthorized');
    echo json_encode(['error' => 'No autorizado']);
    exit;
}

require_once '../config.php';

// Obtener la conexión a la base de datos
$db = conectarDB();

// Determinar el método HTTP
$method = $_SERVER['REQUEST_METHOD'];
if ($method === 'POST' && isset($_POST['_method'])) {
    $method = strtoupper($_POST['_method']);
}

switch ($method) {
    case 'GET':
        // Obtener producto(s)
        if (isset($_GET['id'])) {
            // Obtener un producto específico
            $id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
            $query = "SELECT p.*, m.marca, t.nombre as tipo 
                     FROM productos p
                     JOIN marcas m ON p.id_marca = m.id
                     JOIN `tipo-productos` t ON p.id_tipo = t.id
                     WHERE p.id = :id";
            try {
                $stmt = $db->prepare($query);
                $stmt->execute([':id' => $id]);
                $producto = $stmt->fetch();
                
                if ($producto) {
                    echo json_encode($producto);
                } else {
                    header('HTTP/1.1 404 Not Found');
                    echo json_encode(['error' => 'Producto no encontrado', 'id' => $id]);
                }
            } catch (PDOException $e) {
                header('HTTP/1.1 500 Internal Server Error');
                echo json_encode(['error' => 'Error al obtener producto', 'detalle' => $e->getMessage(), 'query' => $query]);
            }
        } else {
            // Obtener todos los productos
            $query = "SELECT p.id, p.producto, p.imagen, m.marca, t.nombre as tipo 
                     FROM productos p
                     JOIN marcas m ON p.id_marca = m.id
                     JOIN `tipo-productos` t ON p.id_tipo = t.id
                     ORDER BY p.id DESC";
            try {
                $stmt = $db->prepare($query);
                $stmt->execute();
                $productos = $stmt->fetchAll();
                
                echo json_encode($productos);
            } catch (PDOException $e) {
                header('HTTP/1.1 500 Internal Server Error');
                echo json_encode(['error' => 'Error al obtener productos', 'detalle' => $e->getMessage(), 'query' => $query]);
            }
        }
        break;
    
    case 'POST':
        // Crear un nuevo producto
        $producto = filter_input(INPUT_POST, 'producto', FILTER_SANITIZE_STRING);
        $idMarca = filter_input(INPUT_POST, 'id_marca', FILTER_VALIDATE_INT);
        $idTipo = filter_input(INPUT_POST, 'id_tipo', FILTER_VALIDATE_INT);
        $descripcion = filter_input(INPUT_POST, 'descripcion', FILTER_SANITIZE_STRING);
        
        // Validar datos
        $errores = [];
        if (!$producto) $errores[] = 'El nombre del producto es obligatorio';
        if (!$idMarca) $errores[] = 'La marca del producto es obligatoria';
        if (!$idTipo) $errores[] = 'El tipo de producto es obligatorio';
        
        if (!empty($errores)) {
            header('HTTP/1.1 400 Bad Request');
            echo json_encode([
                'error' => 'Datos incompletos', 
                'detalles' => $errores,
                'datos_recibidos' => [
                    'producto' => $producto,
                    'id_marca' => $idMarca,
                    'id_tipo' => $idTipo
                ]
            ]);
            exit;
        }
        
        // Procesar imagen si existe
        $imagenUrl = null;
        $errorImagen = null;
        if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
            $imagen = $_FILES['imagen'];
            $nombreImagen = generarNombreUnico() . '.' . pathinfo($imagen['name'], PATHINFO_EXTENSION);
            $rutaDestino = '../img/productos/' . $nombreImagen;
            
            // Crear directorio si no existe
            if (!is_dir('../img/productos')) {
                if (!mkdir('../img/productos', 0777, true)) {
                    $errorImagen = 'No se pudo crear el directorio para guardar la imagen';
                }
            }
            
            if (empty($errorImagen) && !move_uploaded_file($imagen['tmp_name'], $rutaDestino)) {
                $errorImagen = 'Error al mover la imagen subida al directorio de destino';
            } else {
                $imagenUrl = 'https://www.gyrglobalelectric.com/pages/img/productos/' . $nombreImagen;
            }
        } elseif (isset($_FILES['imagen']) && $_FILES['imagen']['error'] !== UPLOAD_ERR_NO_FILE) {
            $errorCodigos = [
                UPLOAD_ERR_INI_SIZE => 'El archivo excede el tamaño máximo permitido en php.ini',
                UPLOAD_ERR_FORM_SIZE => 'El archivo excede el tamaño máximo permitido en el formulario',
                UPLOAD_ERR_PARTIAL => 'El archivo se subió parcialmente',
                UPLOAD_ERR_NO_TMP_DIR => 'No hay directorio temporal para subir archivos',
                UPLOAD_ERR_CANT_WRITE => 'No se pudo escribir el archivo en el disco',
                UPLOAD_ERR_EXTENSION => 'Una extensión PHP detuvo la subida del archivo'
            ];
            $errorImagen = isset($errorCodigos[$_FILES['imagen']['error']]) ? 
                $errorCodigos[$_FILES['imagen']['error']] : 
                'Error desconocido al subir la imagen: ' . $_FILES['imagen']['error'];
        }
        
        // Insertar en la base de datos
        $query = "INSERT INTO productos (producto, id_marca, id_tipo, descripcion, imagen) 
                 VALUES (:producto, :id_marca, :id_tipo, :descripcion, :imagen)";
        try {
            $stmt = $db->prepare($query);
            $params = [
                ':producto' => $producto,
                ':id_marca' => $idMarca,
                ':id_tipo' => $idTipo,
                ':descripcion' => $descripcion,
                ':imagen' => $imagenUrl
            ];
            
            if ($stmt->execute($params)) {
                $respuesta = ['success' => true, 'id' => $db->lastInsertId()];
                if ($errorImagen) {
                    $respuesta['advertencia'] = 'Producto creado sin imagen: ' . $errorImagen;
                }
                header('HTTP/1.1 201 Created');
                echo json_encode($respuesta);
            } else {
                $errorInfo = $stmt->errorInfo();
                header('HTTP/1.1 500 Internal Server Error');
                echo json_encode([
                    'error' => 'Error al crear el producto', 
                    'detalle' => $errorInfo[2], 
                    'codigo' => $errorInfo[0],
                    'query' => $query,
                    'imagen_error' => $errorImagen
                ]);
            }
        } catch (PDOException $e) {
            header('HTTP/1.1 500 Internal Server Error');
            echo json_encode([
                'error' => 'Error al crear el producto', 
                'detalle' => $e->getMessage(), 
                'query' => $query,
                'imagen_error' => $errorImagen
            ]);
        }
        break;
    
    case 'PUT':
        // Actualizar un producto existente
        parse_str(file_get_contents("php://input"), $_PUT);
        
        // En PHP no hay $_PUT nativo, así que usamos el método POST para el formulario multipart
        // y manejamos la actualización mediante el ID en la URL
        if (isset($_GET['id'])) {
            $id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
            
            // Obtener datos del formulario
            $producto = filter_input(INPUT_POST, 'producto', FILTER_SANITIZE_STRING);
            $idMarca = filter_input(INPUT_POST, 'id_marca', FILTER_VALIDATE_INT);
            $idTipo = filter_input(INPUT_POST, 'id_tipo', FILTER_VALIDATE_INT);
            $descripcion = filter_input(INPUT_POST, 'descripcion', FILTER_SANITIZE_STRING);
            
            // Validar datos
            $errores = [];
            if (!$producto) $errores[] = 'El nombre del producto es obligatorio';
            if (!$idMarca) $errores[] = 'La marca del producto es obligatoria';
            if (!$idTipo) $errores[] = 'El tipo de producto es obligatorio';
            
            if (!empty($errores)) {
                header('HTTP/1.1 400 Bad Request');
                echo json_encode([
                    'error' => 'Datos incompletos', 
                    'detalles' => $errores,
                    'datos_recibidos' => [
                        'id' => $id,
                        'producto' => $producto,
                        'id_marca' => $idMarca,
                        'id_tipo' => $idTipo
                    ]
                ]);
                exit;
            }
            
            try {
                // Obtener producto actual para la imagen
                $queryActual = "SELECT imagen FROM productos WHERE id = :id";
                $stmtActual = $db->prepare($queryActual);
                $stmtActual->execute([':id' => $id]);
                $productoActual = $stmtActual->fetch();
                
                if (!$productoActual) {
                    header('HTTP/1.1 404 Not Found');
                    echo json_encode(['error' => 'Producto no encontrado para actualizar', 'id' => $id]);
                    exit;
                }
                
                // Procesar imagen si existe
                $imagenUrl = $productoActual['imagen'];
                $errorImagen = null;
                if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
                    $imagen = $_FILES['imagen'];
                    $nombreImagen = generarNombreUnico() . '.' . pathinfo($imagen['name'], PATHINFO_EXTENSION);
                    $rutaDestino = '../img/productos/' . $nombreImagen;
                    
                    // Crear directorio si no existe
                    if (!is_dir('../img/productos')) {
                        if (!mkdir('../img/productos', 0777, true)) {
                            $errorImagen = 'No se pudo crear el directorio para guardar la imagen';
                        }
                    }
                    
                    if (empty($errorImagen) && move_uploaded_file($imagen['tmp_name'], $rutaDestino)) {
                        $imagenUrl = 'https://www.gyrglobalelectric.com/pages/img/productos/' . $nombreImagen;
                        
                        // Eliminar imagen anterior si existe
                        if ($productoActual['imagen']) {
                            $nombreImagenAnterior = basename($productoActual['imagen']);
                            $rutaImagenAnterior = '../img/productos/' . $nombreImagenAnterior;
                            if (file_exists($rutaImagenAnterior)) {
                                if (!unlink($rutaImagenAnterior)) {
                                    $errorImagen = 'No se pudo eliminar la imagen anterior, pero se continuó con la actualización';
                                }
                            }
                        }
                    } else {
                        $errorImagen = 'Error al guardar la nueva imagen en el servidor';
                    }
                } elseif (isset($_FILES['imagen']) && $_FILES['imagen']['error'] !== UPLOAD_ERR_NO_FILE) {
                    $errorCodigos = [
                        UPLOAD_ERR_INI_SIZE => 'El archivo excede el tamaño máximo permitido en php.ini',
                        UPLOAD_ERR_FORM_SIZE => 'El archivo excede el tamaño máximo permitido en el formulario',
                        UPLOAD_ERR_PARTIAL => 'El archivo se subió parcialmente',
                        UPLOAD_ERR_NO_TMP_DIR => 'No hay directorio temporal para subir archivos',
                        UPLOAD_ERR_CANT_WRITE => 'No se pudo escribir el archivo en el disco',
                        UPLOAD_ERR_EXTENSION => 'Una extensión PHP detuvo la subida del archivo'
                    ];
                    $errorImagen = isset($errorCodigos[$_FILES['imagen']['error']]) ? 
                        $errorCodigos[$_FILES['imagen']['error']] : 
                        'Error desconocido al subir la imagen: ' . $_FILES['imagen']['error'];
                }
                
                // Actualizar en la base de datos
                $query = "UPDATE productos SET 
                         producto = :producto,
                         id_marca = :id_marca,
                         id_tipo = :id_tipo,
                         descripcion = :descripcion,
                         imagen = :imagen
                         WHERE id = :id";
                
                $stmt = $db->prepare($query);
                $params = [
                    ':id' => $id,
                    ':producto' => $producto,
                    ':id_marca' => $idMarca,
                    ':id_tipo' => $idTipo,
                    ':descripcion' => $descripcion,
                    ':imagen' => $imagenUrl
                ];
                
                if ($stmt->execute($params)) {
                    $respuesta = ['success' => true, 'mensaje' => 'Producto actualizado correctamente'];
                    if ($errorImagen) {
                        $respuesta['advertencia'] = $errorImagen;
                    }
                    echo json_encode($respuesta);
                } else {
                    $errorInfo = $stmt->errorInfo();
                    header('HTTP/1.1 500 Internal Server Error');
                    echo json_encode([
                        'error' => 'Error al actualizar el producto', 
                        'detalle' => $errorInfo[2], 
                        'codigo' => $errorInfo[0],
                        'query' => $query,
                        'params' => $params,
                        'imagen_error' => $errorImagen
                    ]);
                }
            } catch (PDOException $e) {
                header('HTTP/1.1 500 Internal Server Error');
                echo json_encode([
                    'error' => 'Error al actualizar el producto', 
                    'detalle' => $e->getMessage(), 
                    'codigo' => $e->getCode(),
                    'query' => $query ?? 'No disponible',
                    'id' => $id,
                    'imagen_error' => $errorImagen ?? null
                ]);
            }
        } else {
            header('HTTP/1.1 400 Bad Request');
            echo json_encode(['error' => 'ID no proporcionado']);
        }
        break;
    
    case 'DELETE':
        // Eliminar un producto
        if (isset($_GET['id'])) {
            $id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
            
            try {
                // Obtener información de la imagen
                $queryImagen = "SELECT imagen FROM productos WHERE id = :id";
                $stmtImagen = $db->prepare($queryImagen);
                $stmtImagen->execute([':id' => $id]);
                $producto = $stmtImagen->fetch();
                
                if (!$producto) {
                    header('HTTP/1.1 404 Not Found');
                    echo json_encode(['error' => 'Producto no encontrado para eliminar', 'id' => $id]);
                    exit;
                }
                
                // Eliminar de la base de datos
                $query = "DELETE FROM productos WHERE id = :id";
                $stmt = $db->prepare($query);
                
                if ($stmt->execute([':id' => $id])) {
                    $respuesta = ['success' => true, 'mensaje' => 'Producto eliminado correctamente'];
                    
                    // Eliminar imagen si existe
                    if ($producto && $producto['imagen']) {
                        $nombreImagen = basename($producto['imagen']);
                        $rutaImagen = '../img/productos/' . $nombreImagen;
                        if (file_exists($rutaImagen)) {
                            if (!unlink($rutaImagen)) {
                                $respuesta['advertencia'] = 'No se pudo eliminar la imagen asociada al producto';
                            }
                        }
                    }
                    
                    echo json_encode($respuesta);
                } else {
                    $errorInfo = $stmt->errorInfo();
                    header('HTTP/1.1 500 Internal Server Error');
                    echo json_encode([
                        'error' => 'Error al eliminar el producto', 
                        'detalle' => $errorInfo[2], 
                        'codigo' => $errorInfo[0],
                        'query' => $query,
                        'id' => $id
                    ]);
                }
            } catch (PDOException $e) {
                header('HTTP/1.1 500 Internal Server Error');
                echo json_encode([
                    'error' => 'Error al eliminar el producto', 
                    'detalle' => $e->getMessage(), 
                    'codigo' => $e->getCode(),
                    'query' => $query ?? 'No disponible',
                    'id' => $id
                ]);
            }
        } else {
            header('HTTP/1.1 400 Bad Request');
            echo json_encode(['error' => 'ID no proporcionado']);
        }
        break;
    
    default:
        header('HTTP/1.1 405 Method Not Allowed');
        echo json_encode(['error' => 'Método no permitido']);
        break;
}

// Función para generar nombre único para las imágenes
function generarNombreUnico() {
    return uniqid('producto_') . '_' . time();
}
?>