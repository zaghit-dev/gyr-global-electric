<?php
// api/marcas.php - API para gestionar marcas
session_start();

// Verificar que el usuario esté logueado
if (!isset($_SESSION['usuario_id'])) {
    header('HTTP/1.1 401 Unauthorized');
    echo json_encode(['error' => 'No autorizado']);
    exit;
}

require_once '../config.php';

// Obtener la conexión a la base de datos
$db = conectarDB();

// Determinar el método HTTP
$method = $_SERVER['REQUEST_METHOD'];
if ($method === 'POST' && isset($_POST['_method'])) {
    $method = strtoupper($_POST['_method']);
}
switch ($method) {
    case 'GET':
        // Obtener marca(s)
        if (isset($_GET['id'])) {
            // Obtener una marca específica
            $id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
            $query = "SELECT * FROM marcas WHERE id = :id";
            $stmt = $db->prepare($query);
            $stmt->execute([':id' => $id]);
            $marca = $stmt->fetch();
            
            if ($marca) {
                echo json_encode($marca);
            } else {
                header('HTTP/1.1 404 Not Found');
                echo json_encode(['error' => 'Marca no encontrada']);
            }
        } else {
            // Obtener todas las marcas
            $query = "SELECT * FROM marcas ORDER BY marca ASC";
            $stmt = $db->prepare($query);
            $stmt->execute();
            $marcas = $stmt->fetchAll();
            
            echo json_encode($marcas);
        }
        break;
    
    case 'POST':
        // Crear una nueva marca
        $marca = filter_input(INPUT_POST, 'marca', FILTER_SANITIZE_STRING);
        
        // Validar datos
        if (!$marca) {
            header('HTTP/1.1 400 Bad Request');
            echo json_encode(['error' => 'Datos incompletos']);
            exit;
        }
        
        // Procesar imagen si existe
        $imagenUrl = null;
        if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
            $imagen = $_FILES['imagen'];
            $nombreImagen = generarNombreUnico() . '.' . pathinfo($imagen['name'], PATHINFO_EXTENSION);
            $rutaDestino = '../img/marcas/' . $nombreImagen;
            
            // Crear directorio si no existe
            if (!is_dir('../img/marcas')) {
                mkdir('../img/marcas', 0777, true);
            }
            
            if (move_uploaded_file($imagen['tmp_name'], $rutaDestino)) {
                $imagenUrl = 'https://www.gyrglobalelectric.com/pages/img/marcas/' . $nombreImagen;
            }
        }
        
        // Insertar en la base de datos
        $query = "INSERT INTO marcas (marca, img_marca) VALUES (:marca, :img_marca)";
        $stmt = $db->prepare($query);
        $params = [
            ':marca' => $marca,
            ':img_marca' => $imagenUrl
        ];
        
        if ($stmt->execute($params)) {
            header('HTTP/1.1 201 Created');
            echo json_encode(['success' => true, 'id' => $db->lastInsertId()]);
        } else {
            header('HTTP/1.1 500 Internal Server Error');
            echo json_encode(['error' => 'Error al crear la marca']);
        }
        break;
    
    case 'PUT':
        // Actualizar una marca existente
        parse_str(file_get_contents("php://input"), $_PUT);
        
        // En PHP no hay $_PUT nativo, así que usamos el método POST para el formulario multipart
        // y manejamos la actualización mediante el ID en la URL
        if (isset($_GET['id'])) {
            $id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
            
            // Obtener datos del formulario
            $marca = filter_input(INPUT_POST, 'marca', FILTER_SANITIZE_STRING);
            
            // Validar datos
            if (!$marca) {
                header('HTTP/1.1 400 Bad Request');
                echo json_encode(['error' => 'Datos incompletos']);
                exit;
            }
            
            // Obtener marca actual para la imagen
            $queryActual = "SELECT img_marca FROM marcas WHERE id = :id";
            $stmtActual = $db->prepare($queryActual);
            $stmtActual->execute([':id' => $id]);
            $marcaActual = $stmtActual->fetch();
            
            // Procesar imagen si existe
            $imagenUrl = $marcaActual['img_marca'];
            if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
                $imagen = $_FILES['imagen'];
                $nombreImagen = generarNombreUnico() . '.' . pathinfo($imagen['name'], PATHINFO_EXTENSION);
                $rutaDestino = '../img/marcas/' . $nombreImagen;
                
                // Crear directorio si no existe
                if (!is_dir('../img/marcas')) {
                    mkdir('../img/marcas', 0777, true);
                }
                
                if (move_uploaded_file($imagen['tmp_name'], $rutaDestino)) {
                    $imagenUrl = 'https://www.gyrglobalelectric.com/pages/img/marcas/' . $nombreImagen;
                    
                    // Eliminar imagen anterior si existe
                    if ($marcaActual['img_marca']) {
                        $nombreImagenAnterior = basename($marcaActual['img_marca']);
                        $rutaImagenAnterior = '../img/marcas/' . $nombreImagenAnterior;
                        if (file_exists($rutaImagenAnterior)) {
                            unlink($rutaImagenAnterior);
                        }
                    }
                }
            }
            
            // Actualizar en la base de datos
            $query = "UPDATE marcas SET marca = :marca, img_marca = :img_marca WHERE id = :id";
            $stmt = $db->prepare($query);
            $params = [
                ':id' => $id,
                ':marca' => $marca,
                ':img_marca' => $imagenUrl
            ];
            
            if ($stmt->execute($params)) {
                echo json_encode(['success' => true]);
            } else {
                header('HTTP/1.1 500 Internal Server Error');
                echo json_encode(['error' => 'Error al actualizar la marca']);
            }
        } else {
            header('HTTP/1.1 400 Bad Request');
            echo json_encode(['error' => 'ID no proporcionado']);
        }
        break;
    
    case 'DELETE':
        // Eliminar una marca
        if (isset($_GET['id'])) {
            $id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
            
            // Verificar si hay productos asociados
            $queryProductos = "SELECT COUNT(*) FROM productos WHERE id_marca = :id";
            $stmtProductos = $db->prepare($queryProductos);
            $stmtProductos->execute([':id' => $id]);
            $tieneProductos = $stmtProductos->fetchColumn() > 0;
            
            if ($tieneProductos) {
                header('HTTP/1.1 400 Bad Request');
                echo json_encode(['error' => 'No se puede eliminar esta marca porque tiene productos asociados']);
                exit;
            }
            
            // Obtener información de la imagen
            $queryImagen = "SELECT img_marca FROM marcas WHERE id = :id";
            $stmtImagen = $db->prepare($queryImagen);
            $stmtImagen->execute([':id' => $id]);
            $marca = $stmtImagen->fetch();
            
            // Eliminar de la base de datos
            $query = "DELETE FROM marcas WHERE id = :id";
            $stmt = $db->prepare($query);
            
            if ($stmt->execute([':id' => $id])) {
                // Eliminar imagen si existe
                if ($marca && $marca['img_marca']) {
                    $nombreImagen = basename($marca['img_marca']);
                    $rutaImagen = '../img/marcas/' . $nombreImagen;
                    if (file_exists($rutaImagen)) {
                        unlink($rutaImagen);
                    }
                }
                
                echo json_encode(['success' => true]);
            } else {
                header('HTTP/1.1 500 Internal Server Error');
                echo json_encode(['error' => 'Error al eliminar la marca']);
            }
        } else {
            header('HTTP/1.1 400 Bad Request');
            echo json_encode(['error' => 'ID no proporcionado']);
        }
        break;
    
    default:
        header('HTTP/1.1 405 Method Not Allowed');
        echo json_encode(['error' => 'Método no permitido']);
        break;
}

// Función para generar nombre único para las imágenes
function generarNombreUnico() {
    return uniqid('marca_') . '_' . time();
}
?>