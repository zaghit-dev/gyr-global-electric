<?php
// cerrar_sesion.php - Cierra la sesión del usuario
session_start();
session_destroy();
header('Location: ../login.php');
exit;
?>