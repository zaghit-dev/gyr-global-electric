<?php
// administracion.php - Sistema de administración
session_start();

// Verificar que el usuario esté logueado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

// Incluir archivo de configuración
require_once 'config.php';
?>
<!DOCTYPE html>
<html lang="es">
<!-- [Head] start -->

<head>
  <title>Sistema gyrg lobal electric</title>
  <!-- [Meta] -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="description" content="Sistema gyrg lobal electric">
  <meta name="keywords" content="Sistema gyrg lobal electric">
  <meta name="author" content="CodedThemes">

  <!-- [Favicon] icon -->
  <link rel="icon" href="img/minilogo.png" type="image/x-icon"> <!-- [Google Font] Family -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Public+Sans:wght@300;400;500;600;700&display=swap" id="main-font-link">
<!-- [Tabler Icons] https://tablericons.com -->
<link rel="stylesheet" href="../assets/fonts/tabler-icons.min.css" >
<!-- [Feather Icons] https://feathericons.com -->
<link rel="stylesheet" href="../assets/fonts/feather.css" >
<!-- [Font Awesome Icons] https://fontawesome.com/icons -->
<link rel="stylesheet" href="../assets/fonts/fontawesome.css" >
<!-- [Material Icons] https://fonts.google.com/icons -->
<link rel="stylesheet" href="../assets/fonts/material.css" >
<!-- [Template CSS Files] -->
<link rel="stylesheet" href="../assets/css/style.css" id="main-style-link" >
<link rel="stylesheet" href="../assets/css/style-preset.css" >
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- DataTables CSS -->
    <link href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <!-- SweetAlert2 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
</head>
<style>
.img-fluid {
    max-width: 80%;
    height: auto;
}
</style>  

<body data-pc-preset="preset-1" data-pc-direction="ltr" data-pc-theme="light">
  <!-- [ Pre-loader ] start -->
<div class="loader-bg">
  <div class="loader-track">
    <div class="loader-fill"></div>
  </div>
</div>
<!-- [ Pre-loader ] End -->
 <!-- [ Sidebar Menu ] start -->
<nav class="pc-sidebar">
  <div class="navbar-wrapper">
    <div class="m-header">
      <a href="#" class="b-brand text-primary">
        <!-- ========   Change your logo from here   ============ -->
        <img src="img/LOGO.png" class="img-fluid" alt="logo">
      </a>
    </div>
    <div class="navbar-content">
      <ul class="pc-navbar">
        <li class="pc-item">
          <a href="#" class="pc-link">
            <span class="pc-micon"><i class="ti ti-dashboard"></i></span>
            <span class="pc-mtext">Productos</span>
          </a>
        </li>
      </ul>
     
    </div>
  </div>
</nav>
<!-- [ Sidebar Menu ] end --> <!-- [ Header Topbar ] start -->
<header class="pc-header">
  <div class="header-wrapper"> <!-- [Mobile Media Block] start -->
<div class="me-auto pc-mob-drp">
  <ul class="list-unstyled">
    <!-- ======= Menu collapse Icon ===== -->
    <li class="pc-h-item pc-sidebar-collapse">
      <a href="#" class="pc-head-link ms-0" id="sidebar-hide">
        <i class="ti ti-menu-2"></i>
      </a>
    </li>
    <li class="pc-h-item pc-sidebar-popup">
      <a href="#" class="pc-head-link ms-0" id="mobile-collapse">
        <i class="ti ti-menu-2"></i>
      </a>
    </li>
    <li class="dropdown pc-h-item d-inline-flex d-md-none">
      <a
        class="pc-head-link dropdown-toggle arrow-none m-0"
        data-bs-toggle="dropdown"
        href="#"
        role="button"
        aria-haspopup="false"
        aria-expanded="false"
      >
        <i class="ti ti-search"></i>
      </a>
      <div class="dropdown-menu pc-h-dropdown drp-search">
        <form class="px-3">
          <div class="form-group mb-0 d-flex align-items-center">
            <i data-feather="search"></i>
            <input type="search" class="form-control border-0 shadow-none" placeholder="Search here. . .">
          </div>
        </form>
      </div>
    </li>
    <li class="pc-h-item d-none d-md-inline-flex">
      <form class="header-search">
        <i data-feather="search" class="icon-search"></i>
        <input type="search" class="form-control" placeholder="Search here. . .">
      </form>
    </li>
  </ul>
</div>
<!-- [Mobile Media Block end] -->

 </div>
</header>
<!-- [ Header ] end -->



  <!-- [ Main Content ] start -->
  <div class="pc-container">
    <div class="pc-content">
      <!-- [ breadcrumb ] start -->
      <div class="page-header">
        <div class="page-block">
          <div class="row align-items-center">
            <div class="col-md-12">
              <div class="page-header-title">
                <h5 class="m-b-10">PRODUCTOS</h5>
              </div>
              <ul class="breadcrumb">
                <li class="breadcrumb-item"><a href="../dashboard/index.html">EDITAR</a></li>
                <li class="breadcrumb-item"><a href="javascript: void(0)">Lista de productos</a></li>

              </ul>
            </div>
          </div>
        </div>
      </div>
      <!-- [ breadcrumb ] end -->

      <!-- [ Main Content ] start -->
      <div class="container mt-4">
        <div class="row">
            <!-- Sección de Productos -->
            <div class="col-md-7 mb-4">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">PRODUCTOS</h5>
                    </div>
                    <div class="card-body">
                        <button type="button" class="btn btn-success mb-3" id="btnNuevoProducto">
                            <i class="bi bi-plus-circle"></i> Nuevo Producto
                        </button>
                        <div class="table-responsive">
                            <table id="tablaProductos" class="table table-striped table-hover" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Producto</th>
                                        <th>Marca</th>
                                        <th>Tipo</th>
                                        <th>Imagen</th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <!-- Los datos se cargarán dinámicamente -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Sección de Marcas -->
            <div class="col-md-5 mb-4">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">MARCAS</h5>
                    </div>
                    <div class="card-body">
                        <button type="button" class="btn btn-success mb-3" id="btnNuevaMarca">
                            <i class="bi bi-plus-circle"></i> Nueva Marca
                        </button>
                        <div class="table-responsive">
                            <table id="tablaMarcas" class="table table-striped table-hover" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Marca</th>
                                        <th>Imagen</th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <!-- Los datos se cargarán dinámicamente -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
      <!-- [ Main Content ] end -->
    </div>
  </div>
  <div class="modal fade" id="modalProducto" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="tituloModalProducto">Nuevo Producto</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="formProducto" enctype="multipart/form-data">
                        <input type="hidden" id="idProducto" name="id">
                        
                        <div class="row mb-3">
                           
                            <div class="col-md-12">
                                <label for="producto" class="form-label">Producto</label>
                                <input type="text" class="form-control" id="producto" name="producto" required>
                            </div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="idMarca" class="form-label">Marca</label>
                                <select class="form-select" id="idMarca" name="id_marca" required>
                                    <option value="">Seleccione una marca</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label for="idTipo" class="form-label">Tipo</label>
                                <select class="form-select" id="idTipo" name="id_tipo" required>
                                    <option value="">Seleccione un tipo</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="descripcion" class="form-label">Descripción</label>
                            <textarea class="form-control" id="descripcion" name="descripcion" rows="3"></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label for="imagen" class="form-label">Imagen</label>
                            <input type="file" class="form-control" id="imagen" name="imagen" accept="image/*">
                            <div id="previewImagen" class="mt-2 d-none">
                                <img src="" alt="Vista previa" class="img-thumbnail" style="max-height: 200px;">
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-primary" id="btnGuardarProducto">Guardar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal para Marcas -->
    <div class="modal fade" id="modalMarca" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="tituloModalMarca">Nueva Marca</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="formMarca" enctype="multipart/form-data">
                        <input type="hidden" id="idMarcaForm" name="id">
                        
                        <div class="mb-3">
                            <label for="marcaNombre" class="form-label">Nombre de la Marca</label>
                            <input type="text" class="form-control" id="marcaNombre" name="marca" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="imagenMarca" class="form-label">Imagen</label>
                            <input type="file" class="form-control" id="imagenMarca" name="imagen" accept="image/*">
                            <div id="previewImagenMarca" class="mt-2 d-none">
                                <img src="" alt="Vista previa" class="img-thumbnail" style="max-height: 200px;">
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-primary" id="btnGuardarMarca">Guardar</button>
                </div>
            </div>
        </div>
    </div>
  <footer class="pc-footer">
    <div class="footer-wrapper container-fluid">
      <div class="row">
        <div class="col-sm my-1">
          <p class="m-0"
            >Mantis &#9829; crafted by Team <a href="https://themeforest.net/user/codedthemes" target="_blank">Codedthemes</a> Distributed by <a href="https://themewagon.com/">ThemeWagon</a>.</p
          >
        </div>
        <div class="col-auto my-1">
          <ul class="list-inline footer-link mb-0">
            <li class="list-inline-item"><a href="../index.html">Home</a></li>
          </ul>
        </div>
      </div>
    </div>
  </footer> <!-- Required Js -->
<script src="../assets/js/plugins/popper.min.js"></script>
<script src="../assets/js/plugins/simplebar.min.js"></script>
<script src="../assets/js/plugins/bootstrap.min.js"></script>
<script src="../assets/js/fonts/custom-font.js"></script>
<script src="../assets/js/pcoded.js"></script>
<script src="../assets/js/plugins/feather.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- DataTables JS -->
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <!-- SweetAlert2 JS -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        $(document).ready(function() {
            // Inicializar DataTables
            const tablaProductos = $('#tablaProductos').DataTable({
                ajax: {
                    url: 'api/productos.php',
                    dataSrc: ''
                },
                columns: [
                    { data: 'id' },
                    { data: 'producto' },
                    { data: 'marca' },
                    { data: 'tipo' },
                    { 
                        data: 'imagen',
                        render: function(data) {
                            return data ? `<img src="${data}" alt="Producto" style="max-height: 50px;">` : 'Sin imagen';
                        }
                    },
                    {
                        data: null,
                        render: function(data) {
                            return `
                                <button class="btn btn-sm btn-primary editar-producto" data-id="${data.id}">
                                    <i class="bi bi-pencil"></i> Editar
                                </button>
                                <button class="btn btn-sm btn-danger eliminar-producto" data-id="${data.id}">
                                    <i class="bi bi-trash"></i> Eliminar
                                </button>
                            `;
                        }
                    }
                ],
                language: {
                    url: '//cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json'
                }
            });
            
            const tablaMarcas = $('#tablaMarcas').DataTable({
                ajax: {
                    url: 'api/marcas.php',
                    dataSrc: ''
                },
                columns: [
                    { data: 'id' },
                    { data: 'marca' },
                    { 
                        data: 'img_marca',
                        render: function(data) {
                            return data ? `<img src="${data}" alt="Marca" style="max-height: auto;width: 100px;">` : 'Sin imagen';
                        }
                    },
                    {
                        data: null,
                        render: function(data) {
                            return `
                                <button class="btn btn-sm btn-primary editar-marca" data-id="${data.id}">
                                    <i class="bi bi-pencil"></i> Editar
                                </button>
                                <button class="btn btn-sm btn-danger eliminar-marca" data-id="${data.id}">
                                    <i class="bi bi-trash"></i> Eliminar
                                </button>
                            `;
                        }
                    }
                ],
                language: {
                    url: '//cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json'
                }
            });
            
            // Cargar listas desplegables
            cargarMarcas();
            cargarTipos();
            
            // Eventos para productos
            $('#btnNuevoProducto').click(function() {
                $('#formProducto').trigger('reset');
                $('#idProducto').val('');
                $('#previewImagen').addClass('d-none');
                $('#tituloModalProducto').text('Nuevo Producto');
                $('#modalProducto').modal('show');
            });
            
            $('#btnGuardarProducto').click(function() {
                guardarProducto();
            });
            
            $(document).on('click', '.editar-producto', function() {
                const id = $(this).data('id');
                cargarProducto(id);
            });
            
            $(document).on('click', '.eliminar-producto', function() {
                const id = $(this).data('id');
                eliminarProducto(id);
            });
            
            // Eventos para marcas
            $('#btnNuevaMarca').click(function() {
                $('#formMarca').trigger('reset');
                $('#idMarcaForm').val('');
                $('#previewImagenMarca').addClass('d-none');
                $('#tituloModalMarca').text('Nueva Marca');
                $('#modalMarca').modal('show');
            });
            
            $('#btnGuardarMarca').click(function() {
                guardarMarca();
            });
            
            $(document).on('click', '.editar-marca', function() {
                const id = $(this).data('id');
                cargarMarca(id);
            });
            
            $(document).on('click', '.eliminar-marca', function() {
                const id = $(this).data('id');
                eliminarMarca(id);
            });
            
            // Vista previa de imágenes
            $('#imagen').change(function() {
                mostrarVistaPrevia(this, '#previewImagen');
            });
            
            $('#imagenMarca').change(function() {
                mostrarVistaPrevia(this, '#previewImagenMarca');
            });
            
            // Funciones para productos
            function cargarProducto(id) {
                $.ajax({
                    url: 'api/productos.php?id=' + id,
                    type: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        $('#idProducto').val(response.id);
                        $('#producto').val(response.producto);
                        $('#idMarca').val(response.id_marca);
                        $('#idTipo').val(response.id_tipo);
                        $('#descripcion').val(response.descripcion);
                        
                        if (response.imagen) {
                            $('#previewImagen').removeClass('d-none');
                            $('#previewImagen img').attr('src', response.imagen);
                        } else {
                            $('#previewImagen').addClass('d-none');
                        }
                        
                        $('#tituloModalProducto').text('Editar Producto');
                        $('#modalProducto').modal('show');
                    },
                    error: function(xhr) {
                        mostrarError('Error al cargar el producto');
                    }
                });
            }
            
           function guardarProducto() {
                const formData = new FormData($('#formProducto')[0]);
                const id = $('#idProducto').val();
                
                // Cambiar a POST para ambos casos, pero añadir un campo _method para indicar si es PUT
                let url = 'api/productos.php';
                if (id) {
                    url += '?id=' + id;
                    // Opcionalmente puedes añadir un campo que indique que es una actualización
                    formData.append('_method', 'PUT');
                }
                
                $.ajax({
                    url: url,
                    type: 'POST', // Usar siempre POST para formularios con archivos
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        $('#modalProducto').modal('hide');
                        tablaProductos.ajax.reload();
                        Swal.fire({
                            icon: 'success',
                            title: 'Éxito',
                            text: id ? 'Producto actualizado correctamente' : 'Producto creado correctamente'
                        });
                    },
                    error: function(xhr) {
                        let message = 'Error al guardar el producto';
                        if (xhr.responseJSON && xhr.responseJSON.error) {
                            message = xhr.responseJSON.error;
                            if (xhr.responseJSON.detalles) {
                                message += ': ' + xhr.responseJSON.detalles.join(', ');
                            }
                        }
                        mostrarError(message);
                    }
                });
            }
            
            function eliminarProducto(id) {
                Swal.fire({
                    title: '¿Está seguro?',
                    text: "Esta acción no se puede revertir",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Sí, eliminar',
                    cancelButtonText: 'Cancelar'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            url: 'api/productos.php?id=' + id,
                            type: 'DELETE',
                            success: function(response) {
                                tablaProductos.ajax.reload();
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Éxito',
                                    text: 'Producto eliminado correctamente'
                                });
                            },
                            error: function(xhr) {
                                mostrarError('Error al eliminar el producto');
                            }
                        });
                    }
                });
            }
            
            // Funciones para marcas
            function cargarMarca(id) {
                $.ajax({
                    url: 'api/marcas.php?id=' + id,
                    type: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        $('#idMarcaForm').val(response.id);
                        $('#marcaNombre').val(response.marca);
                        
                        if (response.img_marca) {
                            $('#previewImagenMarca').removeClass('d-none');
                            $('#previewImagenMarca img').attr('src', response.img_marca);
                        } else {
                            $('#previewImagenMarca').addClass('d-none');
                        }
                        
                        $('#tituloModalMarca').text('Editar Marca');
                        $('#modalMarca').modal('show');
                    },
                    error: function(xhr) {
                        mostrarError('Error al cargar la marca');
                    }
                });
            }
            
            function guardarMarca() {
                const formData = new FormData($('#formMarca')[0]);
                const id = $('#idMarcaForm').val();
                
                let url = 'api/marcas.php';
                if (id) {
                    url += '?id=' + id;
                    formData.append('_method', 'PUT');
                }
                
                $.ajax({
                    url: url,
                    type: 'POST', // Usar siempre POST para formularios con archivos
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        $('#modalMarca').modal('hide');
                        tablaMarcas.ajax.reload();
                        tablaProductos.ajax.reload();
                        cargarMarcas();
                        Swal.fire({
                            icon: 'success',
                            title: 'Éxito',
                            text: id ? 'Marca actualizada correctamente' : 'Marca creada correctamente'
                        });
                    },
                    error: function(xhr) {
                        let message = 'Error al guardar la marca';
                        if (xhr.responseJSON && xhr.responseJSON.error) {
                            message = xhr.responseJSON.error;
                        }
                        mostrarError(message);
                    }
                });
            }
            
            function eliminarMarca(id) {
                Swal.fire({
                    title: '¿Está seguro?',
                    text: "Esta acción no se puede revertir",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Sí, eliminar',
                    cancelButtonText: 'Cancelar'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            url: 'api/marcas.php?id=' + id,
                            type: 'DELETE',
                            success: function(response) {
                                tablaMarcas.ajax.reload();
                                tablaProductos.ajax.reload(); // Recargar productos por si cambian las marcas
                                cargarMarcas(); // Recargar lista desplegable
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Éxito',
                                    text: 'Marca eliminada correctamente'
                                });
                            },
                            error: function(xhr) {
                                mostrarError('Error al eliminar la marca');
                            }
                        });
                    }
                });
            }
            
            // Funciones auxiliares
            function cargarMarcas() {
                $.ajax({
                    url: 'api/marcas.php',
                    type: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        $('#idMarca').empty().append('<option value="">Seleccione una marca</option>');
                        response.forEach(function(marca) {
                            $('#idMarca').append(`<option value="${marca.id}">${marca.marca}</option>`);
                        });
                    }
                });
            }
            
            function cargarTipos() {
                $.ajax({
                    url: 'api/tipos.php',
                    type: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        $('#idTipo').empty().append('<option value="">Seleccione un tipo</option>');
                        response.forEach(function(tipo) {
                            $('#idTipo').append(`<option value="${tipo.id}">${tipo.nombre}</option>`);
                        });
                    }
                });
            }
            
            function mostrarVistaPrevia(input, previewSelector) {
                if (input.files && input.files[0]) {
                    const reader = new FileReader();
                    
                    reader.onload = function(e) {
                        $(previewSelector).removeClass('d-none');
                        $(previewSelector + ' img').attr('src', e.target.result);
                    }
                    
                    reader.readAsDataURL(input.files[0]);
                } else {
                    $(previewSelector).addClass('d-none');
                }
            }
            
            function mostrarError(mensaje) {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: mensaje
                });
            }
        });
    </script>



<script>layout_change('light');</script>




<script>change_box_container('false');</script>



<script>layout_rtl_change('false');</script>


<script>preset_change("preset-1");</script>


<script>font_change("Public-Sans");</script>

    

  <script src="../assets/js/plugins/clipboard.min.js"></script>
  <script>
    window.addEventListener('load', (event) => {
      var i_copy = new ClipboardJS('.color-block');
      i_copy.on('success', function (e) {
        var targetElement = e.trigger;
        let icon_badge = document.createElement('span');
        icon_badge.setAttribute('class', 'ic-badge badge bg-success float-end');
        icon_badge.innerHTML = 'copied';
        targetElement.append(icon_badge);
        setTimeout(function () {
          targetElement.children[0].remove();
        }, 3000);
      });

      i_copy.on('error', function (e) {
        var targetElement = e.trigger;
        let icon_badge = document.createElement('span');
        icon_badge.setAttribute('class', 'ic-badge badge bg-danger float-end');
        icon_badge.innerHTML = 'Error';
        targetElement.append(icon_badge);
        setTimeout(function () {
          targetElement.children[0].remove();
        }, 3000);
      });
    });
  </script>
</body>
<!-- [Body] end -->
</html>

