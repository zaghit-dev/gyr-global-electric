<?php
$conn=mysqli_connect("localhost", "u217227092_global", "7249Global","u217227092_global");
$conn -> set_charset("utf8mb4");
?>