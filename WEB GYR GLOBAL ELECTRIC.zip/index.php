<?php
require("global/conexion.php");
?>
<!DOCTYPE html>
<html lang="es">

<head>
	
	<meta charset="UTF-8">
	<meta name="facebook-domain-verification" content="5kc9dwkxslrcusfyn7nh9upwp32u59" />
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta content="IE=edge,chrome=1" http-equiv="X-UA-Compatible">
	<meta content="follow,index" name="robots">
	<title>G&R Global Electric Solución Industrial</title>
	<meta content="G&R Global Electric Solución Industrial" name="description">
	<meta content="Global Electric Solución Industrial es una empresa peruana del sector industrial dedicada a la distribución de productos eléctricos como iluminación, electricidad y ferretería con cobertura a nivel nacional ." name="description">
	<!--===============================================================================================-->
	<link rel="icon" type="image/png" href="https://i.postimg.cc/sxFD4KB8/d60966d3-54d3-444a-b720-110e5a33024c-auto-x2-removebg-preview-removebg-preview-1.png"/>
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/linearicons-v1.0.0/icon-font.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/slick/slick.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/MagnificPopup/magnific-popup.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/perfect-scrollbar/perfect-scrollbar.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/styles.css">
	<link rel="stylesheet" type="text/css" href="icons.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-6872475020900549"
     crossorigin="anonymous"></script>
	<!--===============================================================================================-->
</head>
<style>
    .p-b-10 a{
    color: #dbdbdb!important;
}    
.stext-107{
    color: #dbdbdb!important;
}
</style>
<body class="animsition">

	<!-- Header -->
	<?php
	include 'templates/header.php'
	?>

	<!-- Sidebar -->
 
<h1  style="position: absolute;color: #fff0;
    background-color: #fff0;">G&R Global Electric Solución Industrial</h1>
	<section class="section-slide">
	      
		<div class="wrap-slick1 rs2-slick1">
			<div class="slick1">
			 <?php
								$consulta = $conn->query("SELECT * FROM `carousel` where id='1'");
								while ($fila = $consulta->fetch_array()) {
				                ?>
				<div class="item-slick1 bg-overlay1" style="background-image: url(<?php echo $fila['img']; ?>);" data-thumb="https://i.postimg.cc/vTwsJyM7/stuck-940x470.jpg">
			    <?php } ?>
					<div class="container h-full">
						<div class="flex-col-c-m h-full p-t-100 p-b-60 respon5">
						     <?php
								$consulta = $conn->query("SELECT * FROM `Animacion` where id='1'");
								while ($fila = $consulta->fetch_array()) {
				                ?>
							<div class="layer-slick1 animated visible-false" data-appear="<?php echo $fila['tipo']; ?>" data-delay="0">
				        	<?php } ?>	
				        	<?php
								$consulta = $conn->query("SELECT * FROM `carousel` where id='1'");
								while ($fila = $consulta->fetch_array()) {
				                ?>
								<p style="font-family: Helvetica, Arial, sans-serif; text-align: center;color: #fff;font-size: 28px;">
									<?php echo $fila['subtitulo_1']; ?>
								</p>
								<?php } ?>
							</div>
                            <?php
								$consulta = $conn->query("SELECT * FROM `Animacion` where id='2'");
								while ($fila = $consulta->fetch_array()) {
				                ?>
							<div class="layer-slick1 animated visible-false" data-appear="<?php echo $fila['tipo']; ?>" data-delay="800">
							 <?php } ?>
							 <?php
								$consulta = $conn->query("SELECT * FROM `carousel` where id='1'");
								while ($fila = $consulta->fetch_array()) {
				                ?>
								<h2 class="ltext-104 txt-center cl0 p-t-22 p-b-40 respon1">
									<?php echo $fila['titulo']; ?>
								</h2>
							<?php } ?>
							</div>
							<style>
								.p-b-40,
								.p-tb-40,
								.p-all-40 {
									padding-bottom: 25px;
								}
							</style>
							<?php
								$consulta = $conn->query("SELECT * FROM `Animacion` where id='3'");
								while ($fila = $consulta->fetch_array()) {
				                ?>
							<div class="layer-slick1 animated visible-false" data-appear="<?php echo $fila['tipo']; ?>" data-delay="1600">
							 <?php } ?>
							 <?php
								$consulta = $conn->query("SELECT * FROM `carousel` where id='1'");
								while ($fila = $consulta->fetch_array()) {
				                ?>
								<span class="ltext-202 txt-center cl0 respon2" style="font-family: Helvetica, Arial, sans-serif; text-align: center;">
									<?php echo $fila['subtitulo_2']; ?>
									</span>
								<?php } ?>
							</div>
						</div>
					</div>
				</div>

			
			
			
			
			<?php
								$consulta = $conn->query("SELECT * FROM `carousel` where id='2'");
								while ($fila = $consulta->fetch_array()) {
				                ?>
				<div class="item-slick1 bg-overlay1" style="background-image: url(<?php echo $fila['img']; ?>);" data-thumb="https://i.postimg.cc/vTwsJyM7/stuck-940x470.jpg">
			    <?php } ?>
					<div class="container h-full">
						<div class="flex-col-c-m h-full p-t-100 p-b-60 respon5">
						     <?php
								$consulta = $conn->query("SELECT * FROM `Animacion` where id='4'");
								while ($fila = $consulta->fetch_array()) {
				                ?>
							<div class="layer-slick1 animated visible-false" data-appear="<?php echo $fila['tipo']; ?>" data-delay="0">
				        	<?php } ?>	
				        	<?php
								$consulta = $conn->query("SELECT * FROM `carousel` where id='2'");
								while ($fila = $consulta->fetch_array()) {
				                ?>
								<p style="font-family: Helvetica, Arial, sans-serif; text-align: center;color: #fff;font-size: 28px;">
									<?php echo $fila['subtitulo_1']; ?>
								</p>
								<?php } ?>
							</div>
                            <?php
								$consulta = $conn->query("SELECT * FROM `Animacion` where id='5'");
								while ($fila = $consulta->fetch_array()) {
				                ?>
							<div class="layer-slick1 animated visible-false" data-appear="<?php echo $fila['tipo']; ?>" data-delay="800">
							 <?php } ?>
							 <?php
								$consulta = $conn->query("SELECT * FROM `carousel` where id='2'");
								while ($fila = $consulta->fetch_array()) {
				                ?>
								<h2 class="ltext-104 txt-center cl0 p-t-22 p-b-40 respon1">
									<?php echo $fila['titulo']; ?>
								</h2>
							<?php } ?>
							</div>
							<style>
								.p-b-40,
								.p-tb-40,
								.p-all-40 {
									padding-bottom: 25px;
								}
							</style>
							<?php
								$consulta = $conn->query("SELECT * FROM `Animacion` where id='6'");
								while ($fila = $consulta->fetch_array()) {
				                ?>
							<div class="layer-slick1 animated visible-false" data-appear="<?php echo $fila['tipo']; ?>" data-delay="1600">
							 <?php } ?>
							 <?php
								$consulta = $conn->query("SELECT * FROM `carousel` where id='2'");
								while ($fila = $consulta->fetch_array()) {
				                ?>
								<span class="ltext-202 txt-center cl0 respon2" style="font-family: Helvetica, Arial, sans-serif; text-align: center;">
									<?php echo $fila['subtitulo_2']; ?>
									</span>
								<?php } ?>
							</div>
						</div>
					</div>
				</div>





<?php
								$consulta = $conn->query("SELECT * FROM `carousel` where id='3'");
								while ($fila = $consulta->fetch_array()) {
				                ?>
				<div class="item-slick1 bg-overlay1" style="background-image: url(<?php echo $fila['img']; ?>);" data-thumb="https://i.postimg.cc/vTwsJyM7/stuck-940x470.jpg">
			    <?php } ?>
					<div class="container h-full">
						<div class="flex-col-c-m h-full p-t-100 p-b-60 respon5">
						     <?php
								$consulta = $conn->query("SELECT * FROM `Animacion` where id='7'");
								while ($fila = $consulta->fetch_array()) {
				                ?>
							<div class="layer-slick1 animated visible-false" data-appear="<?php echo $fila['tipo']; ?>" data-delay="0">
				        	<?php } ?>	
				        	<?php
								$consulta = $conn->query("SELECT * FROM `carousel` where id='3'");
								while ($fila = $consulta->fetch_array()) {
				                ?>
								<p style="font-family: Helvetica, Arial, sans-serif; text-align: center;color: #fff;font-size: 28px;">
									<?php echo $fila['subtitulo_1']; ?>
								</p>
								<?php } ?>
							</div>
                            <?php
								$consulta = $conn->query("SELECT * FROM `Animacion` where id='8'");
								while ($fila = $consulta->fetch_array()) {
				                ?>
							<div class="layer-slick1 animated visible-false" data-appear="<?php echo $fila['tipo']; ?>" data-delay="800">
							 <?php } ?>
							 <?php
								$consulta = $conn->query("SELECT * FROM `carousel` where id='3'");
								while ($fila = $consulta->fetch_array()) {
				                ?>
								<h2 class="ltext-104 txt-center cl0 p-t-22 p-b-40 respon1">
									<?php echo $fila['titulo']; ?>
								</h2>
							<?php } ?>
							</div>
							<style>
								.p-b-40,
								.p-tb-40,
								.p-all-40 {
									padding-bottom: 25px;
								}
							</style>
							<?php
								$consulta = $conn->query("SELECT * FROM `Animacion` where id='9'");
								while ($fila = $consulta->fetch_array()) {
				                ?>
							<div class="layer-slick1 animated visible-false" data-appear="<?php echo $fila['tipo']; ?>" data-delay="1600">
							 <?php } ?>
							 <?php
								$consulta = $conn->query("SELECT * FROM `carousel` where id='3'");
								while ($fila = $consulta->fetch_array()) {
				                ?>
								<span class="ltext-202 txt-center cl0 respon2" style="font-family: Helvetica, Arial, sans-serif; text-align: center;">
									<?php echo $fila['subtitulo_2']; ?>
									</span>
								<?php } ?>
							</div>
						</div>
					</div>
				</div>
				
				
				
				<?php
								$consulta = $conn->query("SELECT * FROM `carousel` where id='4'");
								while ($fila = $consulta->fetch_array()) {
				                ?>
				<div class="item-slick1 bg-overlay1" style="background-image: url(<?php echo $fila['img']; ?>);" data-thumb="https://i.postimg.cc/vTwsJyM7/stuck-940x470.jpg">
			    <?php } ?>
					<div class="container h-full">
						<div class="flex-col-c-m h-full p-t-100 p-b-60 respon5">
						     <?php
								$consulta = $conn->query("SELECT * FROM `Animacion` where id='6'");
								while ($fila = $consulta->fetch_array()) {
				                ?>
							<div class="layer-slick1 animated visible-false" data-appear="<?php echo $fila['tipo']; ?>" data-delay="0">
				        	<?php } ?>	
				        	<?php
								$consulta = $conn->query("SELECT * FROM `carousel` where id='1'");
								while ($fila = $consulta->fetch_array()) {
				                ?>
								<p style="font-family: Helvetica, Arial, sans-serif; text-align: center;color: #fff;font-size: 28px;">
									<?php echo $fila['subtitulo_1']; ?>
								</p>
								<?php } ?>
							</div>
                            <?php
								$consulta = $conn->query("SELECT * FROM `Animacion` where id='3'");
								while ($fila = $consulta->fetch_array()) {
				                ?>
							<div class="layer-slick1 animated visible-false" data-appear="<?php echo $fila['tipo']; ?>" data-delay="800">
							 <?php } ?>
							 <?php
								$consulta = $conn->query("SELECT * FROM `carousel` where id='4'");
								while ($fila = $consulta->fetch_array()) {
				                ?>
								<h2 class="ltext-104 txt-center cl0 p-t-22 p-b-40 respon1">
									<?php echo $fila['titulo']; ?>
								</h2>
							<?php } ?>
							</div>
							<style>
								.p-b-40,
								.p-tb-40,
								.p-all-40 {
									padding-bottom: 25px;
								}
							</style>
							<?php
								$consulta = $conn->query("SELECT * FROM `Animacion` where id='9'");
								while ($fila = $consulta->fetch_array()) {
				                ?>
							<div class="layer-slick1 animated visible-false" data-appear="<?php echo $fila['tipo']; ?>" data-delay="1600">
							 <?php } ?>
							 <?php
								$consulta = $conn->query("SELECT * FROM `carousel` where id='4'");
								while ($fila = $consulta->fetch_array()) {
				                ?>
								<span class="ltext-202 txt-center cl0 respon2" style="font-family: Helvetica, Arial, sans-serif; text-align: center;">
									<?php echo $fila['subtitulo_2']; ?>
									</span>
								<?php } ?>
							</div>
						</div>
					</div>
				</div>
			</div>

		</div>
	</section>
	<section>
		<div>
			<div class="slider">
				<div class="slide-track">
				<?php
								$consulta = $conn->query("SELECT * FROM `marcas` ORDER BY RAND()");
								while ($fila = $consulta->fetch_array()) {
				?>
					<div class="slide">
						<img src="<?php echo $fila['img_marca']; ?>" height="50px" width="auto" alt="" style="margin: 20px;height:40px;" />
					</div>
					<?php } ?>
					
					
				</div>
			</div>
		</div>
	</section>
	<style>
		.block1-name {
			color: #eea306;
		}
	</style>
	<!-- Banner -->
	<div class="sec-banner bg0">
		<div class="flex-w flex-c-m">
			<div class="size-202 m-lr-auto respon4">
				<div class="wrap-pic-w">
					<div class="container" style="max-width: 420px;margin-top: 20px">


						<h1 class="p-b-15" style="color:#eea306;font-family: Poppins-Bold;"><b>LO MAS RELEVANTE</b>



						</h1>

						<p class="stext-117 cl6" style="font-size:18px">
							Ingrece al apartado de nuestros productos y descubra las <b>mejores ofertas </b>que tenemos, o visite nuestra historia y quienes somos realmente.
						</p>
						<i class="fa fa-angle-right" style="font-size:80px;color:#eea306"></i><i class="fa fa-angle-right" style="font-size:80px;color:#eea306"></i><i class="fa fa-angle-right" style="font-size:80px;color:#eea306"></i>

					</div>
				</div>


			</div>

			<div class="size-202 m-lr-auto respon4">
				<!-- Block1 -->
				<div class="block1 wrap-pic-w">
					<img src="https://www.nuevatribuna.es/media/nuevatribuna/images/2020/02/24/2020022411543024910.jpg" alt="IMG-BANNER" style="z-index: 1;background-size: cover;
    background-repeat: no-repeat;
    background-position: center center;    
    object-fit: cover;
    height: 280px;
    width: 100%;
">

					<a href="https://www.gyrglobalelectric.com/PRODUCTOS/" class="block1-txt ab-t-l s-full flex-col-l-sb p-lr-38 p-tb-34 trans-03 respon3">
						<div class="block1-txt-child1 flex-col-l">
							<span class="block1-name ltext-102 trans-04 p-b-8" style="font-size:40px;">
								Visita nuestra tienda en linea
							</span>


						</div>

						<div class="block1-txt-child2 p-b-4 trans-05">
							<div class="block1-link stext-101 cl0 trans-09">
								Ver mas
							</div>
						</div>
					</a>
				</div>
			</div>

			<div class="size-202 m-lr-auto respon4">
				<!-- Block1 -->
				<div class="block1 wrap-pic-w">
					<img src="https://i.postimg.cc/WzRdYQpq/NOSOTROS003-1024x613.jpg" alt="IMG-BANNER" style="background-size: cover;
    background-repeat: no-repeat;
    background-position: center center;
        object-fit: cover;
    height: 280px;
    width: 100%;
">

					<a href="https://www.gyrglobalelectric.com/EMPRESA/" class="block1-txt ab-t-l s-full flex-col-l-sb p-lr-38 p-tb-34 trans-03 respon3">
						<div class="block1-txt-child1 flex-col-l">
							<span class="block1-name ltext-102 trans-04 p-b-8" style="font-size:40px;">
								Sobre Nosotros

							</span>


						</div>

						<div class="block1-txt-child2 p-b-4 trans-05">
							<div class="block1-link stext-101 cl0 trans-09">
								Ver mas
							</div>
						</div>
					</a>
				</div>
			</div>
		</div>
	</div>

	<style>
		@-webkit-keyframes scroll {
			0% {
				transform: translateX(0);
			}

			100% {
				transform: translateX(calc(-250px * 7));
			}
		}

		@keyframes scroll {
			0% {
				transform: translateX(0);
			}

			100% {
				transform: translateX(calc(-250px * 7));
			}
		}

		.slider {
			background: white;
			box-shadow: 0 10px 20px -5px rgba(0, 0, 0, 0.125);
height: 85px;			margin: auto;
			overflow: hidden;
			position: relative;

		}

		.slider::before,
		.slider::after {
			background: linear-gradient(to right, white 0%, rgba(255, 255, 255, 0) 100%);
			content: "";
			height: 100px;
			position: absolute;
			width: 200px;
			z-index: 2;
		}

		.slider::after {
			right: 0;
			top: 0;
			transform: rotateZ(180deg);
		}

		.slider::before {
			left: 0;
			top: 0;
		}

		.slider .slide-track {
			-webkit-animation: scroll 40s linear infinite;
			animation: scroll 40s linear infinite;
			display: flex;
			width: calc(250px * 14);
		}

		.slider .slide {
			height: 100px;
		}
	</style>





	<!-- Footer -->
	<?php
	include 'templates/footer.php'
	?>


	<!-- Back to top -->
	<div class="btn-back-to-top" id="myBtn">
		<span class="symbol-btn-back-to-top">
			<i class="zmdi zmdi-chevron-up"></i>
		</span>
	</div>

	<!-- Modal1 -->


	<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
	<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
	<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
	<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
	<script>
		$(".js-select2").each(function() {
			$(this).select2({
				minimumResultsForSearch: 20,
				dropdownParent: $(this).next('.dropDownSelect2')
			});
		})
	</script>
	<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
	<!--===============================================================================================-->
	<script src="vendor/slick/slick.min.js"></script>
	<script src="js/slick-custom.js"></script>
	<!--===============================================================================================-->
	<script src="vendor/parallax100/parallax100.js"></script>
	<script>
		$('.parallax100').parallax100();
	</script>
	<!--===============================================================================================-->
	<script src="vendor/MagnificPopup/jquery.magnific-popup.min.js"></script>
	<script>
		$('.gallery-lb').each(function() { // the containers for all your galleries
			$(this).magnificPopup({
				delegate: 'a',
				type: 'image',
				gallery: {
					enabled: true
				},
				mainClass: 'mfp-fade'
			});
		});
	</script>
	<!--===============================================================================================-->
	<script src="vendor/isotope/isotope.pkgd.min.js"></script>
	<!--===============================================================================================-->
	<script src="vendor/sweetalert/sweetalert.min.js"></script>
	<script>
		$('.js-addwish-b2').on('click', function(e) {
			e.preventDefault();
		});

		$('.js-addwish-b2').each(function() {
			var nameProduct = $(this).parent().parent().find('.js-name-b2').php();
			$(this).on('click', function() {
				swal(nameProduct, "is added to wishlist !", "success");

				$(this).addClass('js-addedwish-b2');
				$(this).off('click');
			});
		});

		$('.js-addwish-detail').each(function() {
			var nameProduct = $(this).parent().parent().parent().find('.js-name-detail').php();

			$(this).on('click', function() {
				swal(nameProduct, "is added to wishlist !", "success");

				$(this).addClass('js-addedwish-detail');
				$(this).off('click');
			});
		});

		/*---------------------------------------------*/

		$('.js-addcart-detail').each(function() {
			var nameProduct = $(this).parent().parent().parent().parent().find('.js-name-detail').php();
			$(this).on('click', function() {
				swal(nameProduct, "is added to cart !", "success");
			});
		});
	</script>
	<!--===============================================================================================-->
	<script src="vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
	<script>
		$('.js-pscroll').each(function() {
			$(this).css('position', 'relative');
			$(this).css('overflow', 'hidden');
			var ps = new PerfectScrollbar(this, {
				wheelSpeed: 1,
				scrollingThreshold: 1000,
				wheelPropagation: false,
			});

			$(window).on('resize', function() {
				ps.update();
			})
		});
	</script>
	<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>

</html>